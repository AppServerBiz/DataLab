import express from 'express';
import cors from 'cors';
import multer from 'multer';
import { parseMT5BacktestHTML, parseCSVEquity, decodeBuffer, getRobotNameFromFilename, normalizeRobotName, makeRobotId, ParsedBacktestData, ParsedCSVData, mergeBacktestCSVs } from './parser';
import { getDb } from './database';
import { GoogleGenerativeAI } from '@google/generative-ai';
import ExcelJS from 'exceljs';
import 'dotenv/config';

const app = express();
const port = process.env.PORT || 3001;
app.use(cors());
app.use(express.json({ limit: '100mb' }));

const upload = multer({ storage: multer.memoryStorage() });

// POST /api/upload-merge - merge multiple sequential CSVs (and optionally HTML files) into a single robot
app.post('/api/upload-merge', upload.array('files'), async (req, res) => {
  console.log('Upload merge request received at /api/upload-merge');
  try {
    const db = await getDb();
    const files = req.files as Express.Multer.File[];

    if (!files || files.length === 0) {
      return res.status(400).json({ error: 'Nenhum arquivo enviado.' });
    }

    const csvFiles: { filename: string; content: string; buffer: Buffer }[] = [];
    const htmlFiles: { filename: string; content: string; buffer: Buffer }[] = [];

    for (const file of files) {
      const ext = file.originalname.split('.').pop()?.toLowerCase();
      const content = decodeBuffer(file.buffer);
      if (ext === 'csv') {
        csvFiles.push({ filename: file.originalname, content, buffer: file.buffer });
      } else if (ext === 'html' || ext === 'htm') {
        htmlFiles.push({ filename: file.originalname, content, buffer: file.buffer });
      }
    }

    if (csvFiles.length === 0) {
      return res.status(400).json({ error: 'Envie pelo menos um arquivo .csv para realizar o merge.' });
    }

    // Determine robot base name
    // Strip trailing part letters/numbers like "- A", "_a", " v28 - a", etc.
    let baseName = getRobotNameFromFilename(csvFiles[0].filename)
      .replace(/\s*[-_]\s*[a-zA-Z0-9]$/i, '')
      .replace(/\s*part[e]?\s*\d+$/i, '')
      .trim();

    if (!baseName) baseName = 'Robô Unificado';

    const mergedName = `${baseName} (Merged)`;
    const robotId = makeRobotId(mergedName);

    // Run merge algorithm
    const mergeResult = mergeBacktestCSVs(csvFiles, mergedName);
    if (!mergeResult.success || !mergeResult.result) {
      return res.status(400).json({ error: mergeResult.error || 'Falha ao juntar backtestes.' });
    }

    const mr = mergeResult.result;

    // Check if robot already exists and is approved
    const existing = await db.get(`SELECT id FROM robots WHERE id = ? AND approved = 1`, [robotId]);
    let finalRobotId = robotId;
    let finalRobotName = mergedName;
    let isStaging = false;
    if (existing) {
      finalRobotId = `${robotId}_pending`;
      finalRobotName = `${mergedName} (Pendente)`;
      isStaging = true;
    }

    // If HTML files were provided, parse metrics and aggregate them
    let parsedHtmlMetrics: any = null;
    let combinedConfigHtml = '';
    let mainHtmlText = '';
    let totalLotsSum = 0;
    let maxLotExposureMax = 0;
    let maxEntriesPerTradeMax = 0;
    let totalTradesSum = 0;
    let shortTradesSum = 0;
    let longTradesSum = 0;
    let grossProfitSum = 0;
    let grossLossSum = 0;
    let profitableTradesSum = 0;
    let losingTradesSum = 0;
    let brokerStr = '';
    let assetStr = 'NAS100';
    let timeframeStr = 'H1';
    let parametersCombined: Record<string, any> = {};

    if (htmlFiles.length > 0) {
      // Sort HTML files to match segments
      for (const hf of htmlFiles) {
        const parsed = parseMT5BacktestHTML(hf.content, finalRobotName);
        const m = parsed.metrics;

        totalTradesSum += m.total_trades || 0;
        shortTradesSum += m.short_trades || 0;
        longTradesSum += m.long_trades || 0;
        grossProfitSum += m.gross_profit || 0;
        grossLossSum += m.gross_loss || 0;
        profitableTradesSum += m.profitable_trades || 0;
        losingTradesSum += m.losing_trades || 0;
        totalLotsSum += m.total_lots || 0;
        if (m.max_lot_exposure > maxLotExposureMax) maxLotExposureMax = m.max_lot_exposure;
        if (m.max_entries_per_trade > maxEntriesPerTradeMax) maxEntriesPerTradeMax = m.max_entries_per_trade;
        if (m.broker) brokerStr = m.broker;
        if (m.asset) assetStr = m.asset;
        if (m.timeframe) timeframeStr = m.timeframe;
        if (m.parameters) parametersCombined = { ...parametersCombined, ...m.parameters };
        if (parsed.configHtml && !combinedConfigHtml) combinedConfigHtml = parsed.configHtml;
        if (!mainHtmlText) mainHtmlText = hf.content;
      }
    }

    const totalNetProfit = mr.totalProfit;
    const profitFactor = Math.abs(grossLossSum) > 0 ? (grossProfitSum / Math.abs(grossLossSum)) : (totalTradesSum > 0 ? 2.0 : 0);
    const winRate = totalTradesSum > 0 ? (profitableTradesSum / totalTradesSum) * 100 : 0;
    const avgProfitPerMonth = mr.totalMonths > 0 ? totalNetProfit / mr.totalMonths : 0;
    const lotsPerMonth = mr.totalMonths > 0 ? totalLotsSum / mr.totalMonths : 0;
    const recoveryFactor = mr.maxDrawdown > 0 ? totalNetProfit / mr.maxDrawdown : 0;
    const expectedPayoff = totalTradesSum > 0 ? totalNetProfit / totalTradesSum : 0;

    await db.run(`
      INSERT INTO robots (
        id, name,
        total_net_profit, max_dd_equity, max_dd_equity_pct, profit_factor,
        total_trades, short_trades, short_win_pct, long_trades, long_win_pct,
        expected_payoff, sharpe_ratio, max_drawdown_abs, initial_deposit,
        gross_profit, gross_loss, recovery_factor, profitable_trades, losing_trades,
        win_rate, avg_win, avg_loss, max_win, max_loss,
        max_consecutive_wins, max_consecutive_losses, avg_trade_duration, quality,
        asset, period, timeframe, date_from, date_to, broker, parameters,
        total_months, avg_profit_per_month, total_lots, lots_per_month, max_lot_exposure, max_entries_per_trade,
        equity_curve, monthly_drawdown, max_dd_from_csv, max_dd_pct_from_csv,
        config_html, raw_html, raw_csv, approved, status, var_95_dd_cap
      ) VALUES (
        ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?
      )
      ON CONFLICT(id) DO UPDATE SET
        total_net_profit=excluded.total_net_profit,
        max_dd_equity=excluded.max_dd_equity,
        max_dd_equity_pct=excluded.max_dd_equity_pct,
        profit_factor=excluded.profit_factor,
        total_trades=excluded.total_trades,
        short_trades=excluded.short_trades,
        short_win_pct=excluded.short_win_pct,
        long_trades=excluded.long_trades,
        long_win_pct=excluded.long_win_pct,
        expected_payoff=excluded.expected_payoff,
        sharpe_ratio=excluded.sharpe_ratio,
        max_drawdown_abs=excluded.max_drawdown_abs,
        initial_deposit=excluded.initial_deposit,
        gross_profit=excluded.gross_profit,
        gross_loss=excluded.gross_loss,
        recovery_factor=excluded.recovery_factor,
        profitable_trades=excluded.profitable_trades,
        losing_trades=excluded.losing_trades,
        win_rate=excluded.win_rate,
        avg_win=excluded.avg_win,
        avg_loss=excluded.avg_loss,
        max_win=excluded.max_win,
        max_loss=excluded.max_loss,
        max_consecutive_wins=excluded.max_consecutive_wins,
        max_consecutive_losses=excluded.max_consecutive_losses,
        avg_trade_duration=excluded.avg_trade_duration,
        quality=excluded.quality,
        asset=excluded.asset,
        period=excluded.period,
        timeframe=excluded.timeframe,
        date_from=excluded.date_from,
        date_to=excluded.date_to,
        broker=excluded.broker,
        parameters=excluded.parameters,
        total_months=excluded.total_months,
        avg_profit_per_month=excluded.avg_profit_per_month,
        total_lots=excluded.total_lots,
        lots_per_month=excluded.lots_per_month,
        max_lot_exposure=excluded.max_lot_exposure,
        max_entries_per_trade=excluded.max_entries_per_trade,
        equity_curve=excluded.equity_curve,
        monthly_drawdown=excluded.monthly_drawdown,
        max_dd_from_csv=excluded.max_dd_from_csv,
        max_dd_pct_from_csv=excluded.max_dd_pct_from_csv,
        config_html=excluded.config_html,
        raw_html=CASE WHEN excluded.raw_html IS NOT NULL THEN excluded.raw_html ELSE raw_html END,
        raw_csv=excluded.raw_csv,
        var_95_dd_cap=excluded.var_95_dd_cap,
        updated_at=CURRENT_TIMESTAMP
    `, [
      finalRobotId, finalRobotName,
      totalNetProfit, mr.maxDrawdown, mr.maxDrawdownPct, profitFactor,
      totalTradesSum, shortTradesSum, shortTradesSum > 0 ? (profitableTradesSum / shortTradesSum) * 100 : 0, longTradesSum, longTradesSum > 0 ? (profitableTradesSum / longTradesSum) * 100 : 0,
      expectedPayoff, 1.5, 0, mr.initialDeposit,
      grossProfitSum, grossLossSum, recoveryFactor, profitableTradesSum, losingTradesSum,
      winRate, 0, 0, 0, 0,
      '', '', '', 100,
      assetStr, `${timeframeStr} (${mr.dateFrom} - ${mr.dateTo})`, timeframeStr, mr.dateFrom, mr.dateTo, brokerStr, JSON.stringify(parametersCombined),
      mr.totalMonths, avgProfitPerMonth, totalLotsSum, lotsPerMonth, maxLotExposureMax, maxEntriesPerTradeMax,
      JSON.stringify(mr.equityCurve),
      JSON.stringify(mr.monthlyDrawdown),
      mr.maxDrawdown,
      mr.maxDrawdownPct,
      combinedConfigHtml, mainHtmlText, mr.mergedCSV, 0, 'pending', mr.var95
    ]);

    res.json({
      success: true,
      processed: [{ id: finalRobotId, name: finalRobotName, hasCSV: true, isStaging, merged: true }]
    });
  } catch (err: any) {
    console.error('Error in /api/upload-merge:', err);
    res.status(500).json({ error: err.message || String(err) });
  }
});

// POST /api/upload - upload HTML and/or CSV files
app.post('/api/upload', upload.array('files'), async (req, res) => {
  console.log('Upload request received at /api/upload');
  try {
    const db = await getDb();
    const files = req.files as Express.Multer.File[];
    
    // Group files by normalized robot name
    const htmlFiles = new Map<string, Express.Multer.File>();
    const csvFiles = new Map<string, Express.Multer.File>();

    for (const file of files) {
      const ext = file.originalname.split('.').pop()?.toLowerCase();
      const robotName = getRobotNameFromFilename(file.originalname);
      const normName = normalizeRobotName(robotName);
      if (ext === 'html' || ext === 'htm') {
        htmlFiles.set(normName, file);
      } else if (ext === 'csv') {
        csvFiles.set(normName, file);
      }
    }

    const processed: any[] = [];

    // Process all HTML files
    for (const [normName, htmlFile] of htmlFiles) {
      const robotName = getRobotNameFromFilename(htmlFile.originalname);
      const robotId = makeRobotId(robotName);

      // Check if this robot name already exists and is approved (approved = 1) in database
      const existing = await db.get(`SELECT id FROM robots WHERE id = ? AND approved = 1`, [robotId]);
      
      let finalRobotId = robotId;
      let finalRobotName = robotName;
      let isStaging = false;
      if (existing) {
        finalRobotId = `${robotId}_pending`;
        finalRobotName = `${robotName} (Pendente)`;
        isStaging = true;
      }

      const htmlText = decodeBuffer(htmlFile.buffer);
      
      // Look for matching CSV text BEFORE parsing HTML (so we can pass it for monthly DD calc)
      let csvParsed: ParsedCSVData | null = null;
      let csvText: string | null = null;
      if (csvFiles.has(normName)) {
        const csvFile = csvFiles.get(normName)!;
        csvText = decodeBuffer(csvFile.buffer);
        csvParsed = parseCSVEquity(csvText, robotName);
      }

      const parsed = parseMT5BacktestHTML(htmlText, robotName, csvParsed);
      const m = parsed.metrics;

      // Upsert robot record
      await db.run(`
        INSERT INTO robots (
          id, name,
          total_net_profit, max_dd_equity, max_dd_equity_pct, profit_factor,
          total_trades, short_trades, short_win_pct, long_trades, long_win_pct,
          expected_payoff, sharpe_ratio, max_drawdown_abs, initial_deposit,
          gross_profit, gross_loss, recovery_factor, profitable_trades, losing_trades,
          win_rate, avg_win, avg_loss, max_win, max_loss,
          max_consecutive_wins, max_consecutive_losses, avg_trade_duration, quality,
          asset, period, timeframe, date_from, date_to, broker, parameters,
          total_months, avg_profit_per_month, total_lots, lots_per_month, max_lot_exposure, max_entries_per_trade,
          equity_curve, monthly_drawdown, max_dd_from_csv, max_dd_pct_from_csv,
          config_html, raw_html, raw_csv, approved, status, var_95_dd_cap
        ) VALUES (
          ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?
        )
        ON CONFLICT(id) DO UPDATE SET
          total_net_profit=excluded.total_net_profit,
          max_dd_equity=excluded.max_dd_equity,
          max_dd_equity_pct=excluded.max_dd_equity_pct,
          profit_factor=excluded.profit_factor,
          total_trades=excluded.total_trades,
          short_trades=excluded.short_trades,
          short_win_pct=excluded.short_win_pct,
          long_trades=excluded.long_trades,
          long_win_pct=excluded.long_win_pct,
          expected_payoff=excluded.expected_payoff,
          sharpe_ratio=excluded.sharpe_ratio,
          max_drawdown_abs=excluded.max_drawdown_abs,
          initial_deposit=excluded.initial_deposit,
          gross_profit=excluded.gross_profit,
          gross_loss=excluded.gross_loss,
          recovery_factor=excluded.recovery_factor,
          profitable_trades=excluded.profitable_trades,
          losing_trades=excluded.losing_trades,
          win_rate=excluded.win_rate,
          avg_win=excluded.avg_win,
          avg_loss=excluded.avg_loss,
          max_win=excluded.max_win,
          max_loss=excluded.max_loss,
          max_consecutive_wins=excluded.max_consecutive_wins,
          max_consecutive_losses=excluded.max_consecutive_losses,
          avg_trade_duration=excluded.avg_trade_duration,
          quality=excluded.quality,
          asset=excluded.asset,
          period=excluded.period,
          timeframe=excluded.timeframe,
          date_from=excluded.date_from,
          date_to=excluded.date_to,
          broker=excluded.broker,
          parameters=excluded.parameters,
          total_months=excluded.total_months,
          avg_profit_per_month=excluded.avg_profit_per_month,
          total_lots=excluded.total_lots,
          lots_per_month=excluded.lots_per_month,
          max_lot_exposure=excluded.max_lot_exposure,
          max_entries_per_trade=excluded.max_entries_per_trade,
          equity_curve=CASE WHEN excluded.equity_curve IS NOT NULL THEN excluded.equity_curve ELSE equity_curve END,
          monthly_drawdown=CASE WHEN excluded.monthly_drawdown IS NOT NULL THEN excluded.monthly_drawdown ELSE monthly_drawdown END,
          max_dd_from_csv=CASE WHEN excluded.max_dd_from_csv > 0 THEN excluded.max_dd_from_csv ELSE max_dd_from_csv END,
          max_dd_pct_from_csv=CASE WHEN excluded.max_dd_pct_from_csv > 0 THEN excluded.max_dd_pct_from_csv ELSE max_dd_pct_from_csv END,
          config_html=excluded.config_html,
          raw_html=CASE WHEN excluded.raw_html IS NOT NULL THEN excluded.raw_html ELSE raw_html END,
          raw_csv=CASE WHEN excluded.raw_csv IS NOT NULL THEN excluded.raw_csv ELSE raw_csv END,
          var_95_dd_cap=excluded.var_95_dd_cap,
          updated_at=CURRENT_TIMESTAMP
      `, [
        finalRobotId, finalRobotName,
        m.total_net_profit, m.max_dd_equity, m.max_dd_equity_pct, m.profit_factor,
        m.total_trades, m.short_trades, m.short_win_pct, m.long_trades, m.long_win_pct,
        m.expected_payoff, m.sharpe_ratio, m.max_drawdown_abs, m.initial_deposit,
        m.gross_profit, m.gross_loss, m.recovery_factor, m.profitable_trades, m.losing_trades,
        m.win_rate, m.avg_win, m.avg_loss, m.max_win, m.max_loss,
        m.max_consecutive_wins, m.max_consecutive_losses, m.avg_trade_duration, m.quality,
        m.asset, m.period, m.timeframe, m.date_from, m.date_to, m.broker, JSON.stringify(m.parameters),
        m.total_months, m.avg_profit_per_month, m.total_lots, m.lots_per_month, m.max_lot_exposure, m.max_entries_per_trade,
        csvParsed ? JSON.stringify(csvParsed.equityCurve) : null,
        m.monthly_drawdown ? JSON.stringify(m.monthly_drawdown) : null,
        csvParsed ? csvParsed.maxDrawdown : 0,
        csvParsed ? csvParsed.maxDrawdownPct : 0,
        parsed.configHtml, htmlText, csvText, 0, 'pending', m.var_95_dd_cap
      ]);

      processed.push({ id: finalRobotId, name: finalRobotName, hasCSV: !!csvParsed, isStaging });
    }

    res.json({ success: true, processed });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: String(err) });
  }
});

app.get('/api/robot/:id/download/:type', async (req, res) => {
  try {
    const { id, type } = req.params;
    const db = await getDb();
    const robot = await db.get(`SELECT name, raw_html, raw_csv FROM robots WHERE id = ?`, [id]);
    if (!robot) return res.status(404).send('Not found');

    if (type === 'html') {
      res.setHeader('Content-Type', 'text/html');
      res.send(robot.raw_html);
    } else if (type === 'csv') {
      res.setHeader('Content-Type', 'text/csv');
      res.send(robot.raw_csv);
    } else {
      res.status(400).send('Invalid type');
    }
  } catch (e) { res.status(500).send(String(e)); }
});

app.get('/api/robot/:id/monthly-dd', async (req, res) => {
  try {
    const db = await getDb();
    const row = await db.get('SELECT monthly_drawdown FROM robots WHERE id = ?', [req.params.id]);
    res.json(row?.monthly_drawdown ? JSON.parse(row.monthly_drawdown) : []);
  } catch (e) { res.json([]); }
});

app.get('/api/comparativo', async (req, res) => {
  try {
    const db = await getDb();
    // Exclude heavy columns: raw_html, raw_csv, equity_curve
    const rows = await db.all(`
      SELECT 
        id, name, total_net_profit, max_dd_equity, max_dd_equity_pct, profit_factor,
        total_trades, short_trades, short_win_pct, long_trades, long_win_pct,
        expected_payoff, sharpe_ratio, max_drawdown_abs, initial_deposit,
        win_rate, avg_profit_per_month, total_months, config_html, approved, status,
        asset, period, timeframe, date_from, date_to, broker, parameters,
        max_dd_from_csv, max_dd_pct_from_csv, created_at, var_95_dd_cap, total_lots, lots_per_month,
        max_lot_exposure, max_entries_per_trade
      FROM robots 
      ORDER BY created_at DESC
    `);
    res.json(rows.map(r => {
      const parameters = r.parameters ? JSON.parse(r.parameters) : {};
      const warnings: string[] = [];

      if (r.id.endsWith('_pending')) {
        const parentId = r.id.replace('_pending', '');
        const parent = rows.find(x => x.id === parentId && x.approved === 1);
        if (parent) {
          const oldFrom = parent.date_from || '';
          const oldTo = parent.date_to || '';
          const newFrom = r.date_from || '';
          const newTo = r.date_to || '';

          if (oldFrom !== newFrom || oldTo !== newTo) {
            warnings.push(`Divergência de datas detectada: Período atual [${oldFrom} a ${oldTo}] vs Novo período [${newFrom} a ${newTo}]`);
          }

          if (oldFrom && oldTo && newFrom && newTo) {
            const dOldFrom = new Date(oldFrom.replace(/\./g, '-'));
            const dOldTo = new Date(oldTo.replace(/\./g, '-'));
            const dNewFrom = new Date(newFrom.replace(/\./g, '-'));
            const dNewTo = new Date(newTo.replace(/\./g, '-'));

            if (dNewFrom > dOldFrom && dNewTo < dOldTo) {
              warnings.push(`Alerta: O novo backteste está contido no período já existente no banco de dados (Novo período é menor e interno: [${newFrom} a ${newTo}] está dentro de [${oldFrom} a ${oldTo}]).`);
            }
          }
        }
      }

      return {
        ...r,
        parameters,
        warnings,
        equity_curve: null
      };
    }));
  } catch (err) { res.status(500).json({ error: String(err) }); }
});

app.get('/api/robots', async (req, res) => {
  try {
    const db = await getDb();
    const rows = await db.all(`
      SELECT 
        id, name, total_net_profit, max_dd_equity, max_dd_equity_pct, profit_factor,
        total_trades, short_trades, short_win_pct, long_trades, long_win_pct,
        expected_payoff, sharpe_ratio, max_drawdown_abs, initial_deposit,
        win_rate, avg_profit_per_month, total_months, config_html, approved, status,
        asset, period, timeframe, date_from, date_to, broker, parameters,
        max_dd_from_csv, max_dd_pct_from_csv, created_at, var_95_dd_cap, total_lots, lots_per_month,
        max_lot_exposure, max_entries_per_trade
      FROM robots 
      WHERE approved = 1 
      ORDER BY total_net_profit DESC
    `);
    res.json(rows.map(r => ({
      ...r,
      parameters: r.parameters ? JSON.parse(r.parameters) : {},
      equity_curve: null
    })));
  } catch (err) { res.status(500).json({ error: String(err) }); }
});

app.get('/api/robot/:id/equity', async (req, res) => {
  try {
    const db = await getDb();
    const row = await db.get(`SELECT equity_curve, max_dd_from_csv, max_dd_pct_from_csv FROM robots WHERE id = ?`, [req.params.id]);
    if (!row) return res.status(404).json({ error: 'Not found' });
    res.json({
      equity_curve: row.equity_curve ? JSON.parse(row.equity_curve) : [],
      max_dd_from_csv: row.max_dd_from_csv,
      max_dd_pct_from_csv: row.max_dd_pct_from_csv
    });
  } catch (err) { res.status(500).json({ error: String(err) }); }
});

app.get('/api/robot/:id/info', async (req, res) => {
  try {
    const db = await getDb();
    const row = await db.get(`SELECT config_html, name, asset, period, broker, parameters FROM robots WHERE id = ?`, [req.params.id]);
    if (!row) return res.status(404).json({ error: 'Not found' });
    res.json({ ...row, parameters: row.parameters ? JSON.parse(row.parameters) : {} });
  } catch (err) { res.status(500).json({ error: String(err) }); }
});

app.post('/api/robot/:id/approve', async (req, res) => {
  try {
    const db = await getDb();
    const targetId = req.params.id;

    if (targetId.endsWith('_pending')) {
      const parentId = targetId.replace('_pending', '');
      
      // Get the staging record details
      const pendingRobot = await db.get(`SELECT * FROM robots WHERE id = ?`, [targetId]);
      if (!pendingRobot) {
        return res.status(404).json({ error: 'Robô pendente não encontrado' });
      }

      // Extract parent name (strip ' (Pendente)')
      const parentName = pendingRobot.name.replace(' (Pendente)', '');

      // Check if parent already exists
      const parentExists = await db.get(`SELECT id FROM robots WHERE id = ?`, [parentId]);

      if (parentExists) {
        // Safe UPDATE: copy all metrics and data columns to keep the original ID in place
        // to prevent CASCADE DELETE from triggering on portfolio links.
        await db.run(`
          UPDATE robots SET
            name = ?,
            total_net_profit = ?, max_dd_equity = ?, max_dd_equity_pct = ?, profit_factor = ?,
            total_trades = ?, short_trades = ?, short_win_pct = ?, long_trades = ?, long_win_pct = ?,
            expected_payoff = ?, sharpe_ratio = ?, max_drawdown_abs = ?, initial_deposit = ?,
            gross_profit = ?, gross_loss = ?, recovery_factor = ?, profitable_trades = ?, losing_trades = ?,
            win_rate = ?, avg_win = ?, avg_loss = ?, max_win = ?, max_loss = ?,
            max_consecutive_wins = ?, max_consecutive_losses = ?, avg_trade_duration = ?, quality = ?,
            asset = ?, period = ?, timeframe = ?, date_from = ?, date_to = ?, broker = ?, parameters = ?,
            total_months = ?, avg_profit_per_month = ?, total_lots = ?, lots_per_month = ?, max_lot_exposure = ?, max_entries_per_trade = ?,
            equity_curve = ?, monthly_drawdown = ?, max_dd_from_csv = ?, max_dd_pct_from_csv = ?,
            config_html = ?, raw_html = ?, raw_csv = ?, approved = 1, status = 'approved', var_95_dd_cap = ?,
            updated_at = CURRENT_TIMESTAMP
          WHERE id = ?
        `, [
          parentName,
          pendingRobot.total_net_profit, pendingRobot.max_dd_equity, pendingRobot.max_dd_equity_pct, pendingRobot.profit_factor,
          pendingRobot.total_trades, pendingRobot.short_trades, pendingRobot.short_win_pct, pendingRobot.long_trades, pendingRobot.long_win_pct,
          pendingRobot.expected_payoff, pendingRobot.sharpe_ratio, pendingRobot.max_drawdown_abs, pendingRobot.initial_deposit,
          pendingRobot.gross_profit, pendingRobot.gross_loss, pendingRobot.recovery_factor, pendingRobot.profitable_trades, pendingRobot.losing_trades,
          pendingRobot.win_rate, pendingRobot.avg_win, pendingRobot.avg_loss, pendingRobot.max_win, pendingRobot.max_loss,
          pendingRobot.max_consecutive_wins, pendingRobot.max_consecutive_losses, pendingRobot.avg_trade_duration, pendingRobot.quality,
          pendingRobot.asset, pendingRobot.period, pendingRobot.timeframe, pendingRobot.date_from, pendingRobot.date_to, pendingRobot.broker, pendingRobot.parameters,
          pendingRobot.total_months, pendingRobot.avg_profit_per_month, pendingRobot.total_lots, pendingRobot.lots_per_month, pendingRobot.max_lot_exposure, pendingRobot.max_entries_per_trade,
          pendingRobot.equity_curve, pendingRobot.monthly_drawdown, pendingRobot.max_dd_from_csv, pendingRobot.max_dd_pct_from_csv,
          pendingRobot.config_html, pendingRobot.raw_html, pendingRobot.raw_csv, pendingRobot.var_95_dd_cap,
          parentId
        ]);

        // Delete staging record
        await db.run(`DELETE FROM robots WHERE id = ?`, [targetId]);
      } else {
        // If no parent exists, just rename this staging record to the original ID and name
        await db.run(`
          UPDATE robots SET
            id = ?,
            name = ?,
            approved = 1,
            status = 'approved',
            updated_at = CURRENT_TIMESTAMP
          WHERE id = ?
        `, [parentId, parentName, targetId]);
      }
    } else {
      await db.run(`UPDATE robots SET approved = 1, status = 'approved', updated_at = CURRENT_TIMESTAMP WHERE id = ?`, [targetId]);
    }
    res.json({ success: true });
  } catch (err) { res.status(500).json({ error: String(err) }); }
});

app.delete('/api/robot/:id', async (req, res) => {
  console.log('DELETE /api/robot/', req.params.id);
  try {
    const db = await getDb();
    await db.run(`DELETE FROM robots WHERE id = ?`, [req.params.id]);
    res.json({ success: true });
  } catch (err) { res.status(500).json({ error: String(err) }); }
});

app.delete('/api/comparativo/clear', async (req, res) => {
  console.log('DELETE /api/comparativo/clear');
  try {
    const db = await getDb();
    await db.run(`DELETE FROM robots WHERE approved = 0`);
    res.json({ success: true });
  } catch (err) { res.status(500).json({ error: String(err) }); }
});

// ══════════════════════════════════════════════════════════
// PORTFOLIO ENDPOINTS
// ══════════════════════════════════════════════════════════

// GET /api/portfolios
app.get('/api/portfolios', async (req, res) => {
  try {
    const db = await getDb();
    const portfolios = await db.all(`SELECT * FROM portfolios ORDER BY created_at DESC`);
    res.json(portfolios);
  } catch (err) { res.status(500).json({ error: String(err) }); }
});

// POST /api/portfolios
app.post('/api/portfolios', async (req, res) => {
  try {
    const db = await getDb();
    const { name, capital, target_dd } = req.body;
    const id = `pf_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    await db.run(
      `INSERT INTO portfolios (id, name, capital, target_dd) VALUES (?, ?, ?, ?)`,
      [id, name, capital ?? 30000, target_dd ?? 5000]
    );
    const portfolio = await db.get(`SELECT * FROM portfolios WHERE id = ?`, [id]);
    res.json(portfolio);
  } catch (err) { res.status(500).json({ error: String(err) }); }
});

// PUT /api/portfolios/:id
app.put('/api/portfolios/:id', async (req, res) => {
  try {
    const db = await getDb();
    const { name, capital, target_dd, manual_dme, locked } = req.body;
    await db.run(
      `UPDATE portfolios SET name = ?, capital = ?, target_dd = ?, manual_dme = ?, locked = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
      [name, capital, target_dd, manual_dme, locked ? 1 : 0, req.params.id]
    );
    res.json({ success: true });
  } catch (err) { res.status(500).json({ error: String(err) }); }
});

// POST /api/portfolios/:id/copy
app.post('/api/portfolios/:id/copy', async (req, res) => {
  try {
    const db = await getDb();
    const sourceId = req.params.id;
    
    // Find source portfolio
    const sourcePf = await db.get(`SELECT * FROM portfolios WHERE id = ?`, [sourceId]);
    if (!sourcePf) {
      return res.status(404).json({ error: 'Portfólio de origem não encontrado' });
    }
    
    // Find robots belonging to the source portfolio
    const sourceRobots = await db.all(
      `SELECT robot_id, weight FROM portfolio_robots WHERE portfolio_id = ?`,
      [sourceId]
    );
    
    // Create new portfolio with a "(Cópia)" suffix
    const newId = `pf_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    const newName = `${sourcePf.name} (Cópia)`;
    
    await db.run(
      `INSERT INTO portfolios (id, name, capital, target_dd, manual_dme, locked) VALUES (?, ?, ?, ?, ?, ?)`,
      [newId, newName, sourcePf.capital, sourcePf.target_dd, sourcePf.manual_dme, 0]
    );
    
    // Copy the robots
    for (const r of sourceRobots) {
      const prId = `pr_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      await db.run(
        `INSERT INTO portfolio_robots (id, portfolio_id, robot_id, weight) VALUES (?, ?, ?, ?)`,
        [prId, newId, r.robot_id, r.weight]
      );
    }
    
    const newPortfolio = await db.get(`SELECT * FROM portfolios WHERE id = ?`, [newId]);
    res.json(newPortfolio);
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

// DELETE /api/portfolios/:id
app.delete('/api/portfolios/:id', async (req, res) => {
  console.log('DELETE /api/portfolios/', req.params.id);
  try {
    const db = await getDb();
    await db.run(`DELETE FROM portfolio_robots WHERE portfolio_id = ?`, [req.params.id]);
    await db.run(`DELETE FROM portfolios WHERE id = ?`, [req.params.id]);
    res.json({ success: true });
  } catch (err) { res.status(500).json({ error: String(err) }); }
});

// GET /api/portfolios/:id/robots
app.get('/api/portfolios/:id/robots', async (req, res) => {
  try {
    const db = await getDb();
    const rows = await db.all(`
      SELECT pr.id as pr_id, pr.weight, pr.robot_id,
        r.name, r.asset, r.timeframe, r.avg_profit_per_month, r.initial_deposit,
        r.max_dd_from_csv, r.max_dd_equity, r.profit_factor, r.sharpe_ratio,
        r.total_trades, r.date_from, r.date_to, r.total_months, r.monthly_drawdown, r.parameters,
        r.total_lots, r.lots_per_month, r.var_95_dd_cap,
        r.max_lot_exposure, r.max_entries_per_trade
      FROM portfolio_robots pr
      JOIN robots r ON r.id = pr.robot_id
      WHERE pr.portfolio_id = ?
      ORDER BY pr.created_at ASC
    `, [req.params.id]);
    res.json(rows);
  } catch (err) { res.status(500).json({ error: String(err) }); }
});

// POST /api/portfolios/:id/robots
app.post('/api/portfolios/:id/robots', async (req, res) => {
  try {
    const db = await getDb();
    const { robot_id, weight } = req.body;
    const id = `pr_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    await db.run(
      `INSERT INTO portfolio_robots (id, portfolio_id, robot_id, weight) VALUES (?, ?, ?, ?)`,
      [id, req.params.id, robot_id, weight ?? 1]
    );
    res.json({ success: true, id });
  } catch (err) { res.status(500).json({ error: String(err) }); }
});

// PUT /api/portfolios/:id/robots/:robotId  — update weight
app.put('/api/portfolios/:id/robots/:robotId', async (req, res) => {
  try {
    const db = await getDb();
    const { weight } = req.body;
    await db.run(
      `UPDATE portfolio_robots SET weight = ? WHERE portfolio_id = ? AND robot_id = ?`,
      [weight, req.params.id, req.params.robotId]
    );
    res.json({ success: true });
  } catch (err) { res.status(500).json({ error: String(err) }); }
});

// DELETE /api/portfolios/:id/robots/:robotId
app.delete('/api/portfolios/:id/robots/:robotId', async (req, res) => {
  console.log('DELETE robot from portfolio', req.params.id, req.params.robotId);
  try {
    const db = await getDb();
    await db.run(
      `DELETE FROM portfolio_robots WHERE portfolio_id = ? AND robot_id = ?`,
      [req.params.id, req.params.robotId]
    );
    res.json({ success: true });
  } catch (err) { res.status(500).json({ error: String(err) }); }
});

// GET /api/portfolios/:id/stats  — computed analytics with true combined DD
app.get('/api/portfolios/:id/stats', async (req, res) => {
  try {
    const db = await getDb();
    const pf = await db.get(`SELECT * FROM portfolios WHERE id = ?`, [req.params.id]);
    if (!pf) return res.status(404).json({ error: 'Portfolio not found' });

    const robots = await db.all(`
      SELECT pr.weight, pr.robot_id,
        r.name, r.asset, r.timeframe, r.avg_profit_per_month, r.initial_deposit,
        r.max_dd_from_csv, r.max_dd_equity, r.profit_factor, r.sharpe_ratio,
        r.total_months, r.monthly_drawdown, r.equity_curve, r.total_trades,
        r.total_lots, r.lots_per_month, r.var_95_dd_cap,
        r.max_lot_exposure, r.max_entries_per_trade
      FROM portfolio_robots pr
      JOIN robots r ON r.id = pr.robot_id
      WHERE pr.portfolio_id = ?
    `, [req.params.id]);

    // 1. Group daily data for each robot
    const robotDailyData: Map<string, Map<string, { profit: number, dd: number, balanceProfit: number }>> = new Map();
    const allGlobalDays: Set<string> = new Set();

    for (const r of robots) {
      const curve = JSON.parse(r.equity_curve || '[]');
      if (curve.length === 0) continue;

      const effectiveInitial = curve[0].equity;
      let robotPeak = effectiveInitial;
      const r_daily_group: Map<string, { profit: number, dd: number, balanceProfit: number }> = new Map();
      let lastBalanceProfit = 0;
      curve.forEach((pt: any) => {
        const day = pt.date ? pt.date.split(' ')[0] : (pt.timestamp ? pt.timestamp.split(' ')[0] : '2020-01-01');
        if (pt.equity > robotPeak) robotPeak = pt.equity;
        const curDD = (robotPeak - pt.equity);
        const profit = pt.equity - effectiveInitial;
        
        // Use real balance if available, otherwise stay at last known balance (step-function)
        if (pt.balance !== undefined) {
          lastBalanceProfit = pt.balance - effectiveInitial;
        }
        const balanceProfit = lastBalanceProfit;

        allGlobalDays.add(day);
        
        // Take the latest state of the day for the robot
        if (!r_daily_group.has(day)) {
          r_daily_group.set(day, { profit, dd: curDD, balanceProfit });
        } else {
          const g = r_daily_group.get(day)!;
          g.profit = profit;
          g.balanceProfit = balanceProfit;
          if (curDD > g.dd) g.dd = curDD;
        }
      });
      robotDailyData.set(r.name, r_daily_group);
    }

    // 2. Build sorted timeline and aggregate with "carry forward"
    const sortedDays = Array.from(allGlobalDays).sort();

    // Pre-calculate average daily profit for each robot to fill gaps
    const robotAverages = new Map<string, { avgProfit: number, avgTrades: number, firstDay: string, lastDay: string, firstProfit: number, lastProfit: number, firstIdx: number, lastIdx: number }>();
    for (const r of robots) {
      const daily = robotDailyData.get(r.name);
      if (!daily || daily.size === 0) continue;
      const days = Array.from(daily.keys()).sort();
      const first = days[0];
      const last = days[days.length - 1];
      const firstData = daily.get(first)!;
      const lastData = daily.get(last)!;
      const totalP = lastData.profit - firstData.profit;
      const numDays = days.length;
      
      robotAverages.set(r.name, {
        avgProfit: totalP / (numDays || 1),
        avgTrades: (r.total_trades || 0) / (numDays || 1),
        firstDay: first,
        lastDay: last,
        firstProfit: firstData.profit,
        lastProfit: lastData.profit,
        firstIdx: sortedDays.indexOf(first),
        lastIdx: sortedDays.indexOf(last)
      });
    }

    const combinedCurve: any[] = [];
    const robotDailyDD: Map<string, Map<string, number>> = new Map(); // For correlation (real DD)
    
    // Track last known state per robot for carry-forward (same as robot_curves)
    const lastKnown = new Map<string, { profit: number, balanceProfit: number, dd: number }>();
    for (const r of robots) {
      lastKnown.set(r.name, { profit: 0, balanceProfit: 0, dd: 0 });
    }

    let globalPeak = pf.capital;
    for (const [dayIdx, day] of sortedDays.entries()) {
      let totalProfit = 0;
      let totalBalanceProfit = 0;
      let totalSumDD = 0; // Sum of individual robot DDs (for the DD chart)

      for (const r of robots) {
        const weight = r.weight || 1;
        const avg = robotAverages.get(r.name);
        const lk = lastKnown.get(r.name)!;
        let profit = lk.profit;
        let balanceProfit = lk.balanceProfit;
        let dd = lk.dd;

        const dayData = robotDailyData.get(r.name)?.get(day);
        if (dayData) {
          profit = dayData.profit;
          balanceProfit = dayData.balanceProfit;
          dd = dayData.dd;
          lastKnown.set(r.name, { profit, balanceProfit, dd });
          
          // Track real DD for correlation only
          if (!robotDailyDD.has(r.name)) robotDailyDD.set(r.name, new Map());
          robotDailyDD.get(r.name)!.set(day, dd * weight);
        }
        
        totalProfit += profit * weight;
        totalBalanceProfit += balanceProfit * weight;
        totalSumDD += dd * weight;
      }

      const currentEquity = pf.capital + totalProfit;
      if (currentEquity > globalPeak) globalPeak = currentEquity;
      const combinedDD = globalPeak - currentEquity;

      combinedCurve.push({ 
        day, 
        profit: totalProfit, 
        balanceProfit: totalBalanceProfit,
        dd: totalSumDD,       // Captures combined intraday drawdowns (User's DD Max Portf.)
        sumDD: combinedDD     // End-of-day equity drop (Secondary)
      });
    }

    const ddMaxPortfolio = combinedCurve.reduce((max, pt) => Math.max(max, pt.dd), 0);
    const ddMaxSumIndividual = combinedCurve.reduce((max, pt) => Math.max(max, pt.sumDD), 0);

    // Top 10 Drawdown Events
    const ddEvents: { day: string, value: number, pct: number }[] = [];
    let currentPeakProfit = 0;
    let inDrawdown = false;
    let maxDayDD = 0;
    let maxDayDate = '';

    for (const pt of combinedCurve) {
      // Find local peaks of the combined intraday DD series
      if (pt.dd > maxDayDD) {
        maxDayDD = pt.dd;
        maxDayDate = pt.day;
      }
      
      if (pt.profit >= currentPeakProfit) {
        if (inDrawdown && maxDayDD > 0) {
          const peakEquity = pf.capital + currentPeakProfit;
          ddEvents.push({
            day: maxDayDate,
            value: maxDayDD,
            pct: peakEquity > 0 ? (maxDayDD / peakEquity) * 100 : 0
          });
          inDrawdown = false;
          maxDayDD = 0;
        }
        currentPeakProfit = pt.profit;
      } else {
        inDrawdown = true;
      }
    }
    const top10DD = ddEvents.sort((a,b) => b.value - a.value).slice(0, 10);

    // Value at Risk Refined: 95th Percentile of DD series
    let var95 = 0;
    if (combinedCurve.length > 5) {
      const allDDs = combinedCurve.map(c => c.dd);
      const sortedDDs = [...allDDs].sort((a,b) => a - b);
      const idx = Math.floor(sortedDDs.length * 0.95);
      const varDDValue = sortedDDs[idx] || 0;
      var95 = pf.capital > 0 ? (varDDValue / pf.capital) * 100 : 0;
    }

    const totalProfitMes = robots.reduce((s, r) => s + (r.avg_profit_per_month * r.weight), 0);
    const somaIndividualDD = robots.reduce((s, r) => s + (r.max_dd_from_csv * r.weight), 0);
    const roiMes = pf.capital > 0 ? (totalProfitMes / pf.capital) * 100 : 0;
    const roiDiaCash = totalProfitMes / 22; 
    const ddMaxPct = pf.capital > 0 ? (ddMaxPortfolio / pf.capital) * 100 : 0;
    const llDdPct = ddMaxPortfolio > 0 ? (totalProfitMes / ddMaxPortfolio) * 100 : 0;
    const avgSharpe = robots.reduce((s, r) => s + (r.sharpe_ratio || 0), 0) / (robots.length || 1);

    // 3. Trailing 12-Month (TTM) Analytics
    const lastDateStr = sortedDays[sortedDays.length - 1];
    const lastDate = new Date(lastDateStr);
    const date12m = new Date(lastDate);
    date12m.setFullYear(lastDate.getFullYear() - 1);
    const date12mStr = date12m.toISOString().split('T')[0];

    const windowRecent = combinedCurve.filter(c => c.day >= date12mStr);
    const windowPast = combinedCurve.filter(c => c.day < date12mStr);

    const calculateWindowStats = (window: any[], windowStartDate: string, windowEndDate: string) => {
      if (window.length === 0) return null;
      const startProfit = window[0].profit;
      const endProfit = window[window.length - 1].profit;
      const profit = endProfit - startProfit;
      
      // Max DD: The maximum combined intraday drawdown observed in this window (Portfolio level)
      const maxDD = window.reduce((max, pt) => Math.max(max, pt.dd || 0), 0);

      // VaR 95% for this window: 95th percentile of the Drawdown series (DME style)
      let windowVar95 = 0;
      if (window.length > 5) {
        // Use c.dd (which is totalSumDD) to provide a more conservative sum-based VaR
        const dds = window.map(c => c.dd || 0);
        dds.sort((a, b) => a - b);
        const idx = Math.floor(dds.length * 0.95);
        windowVar95 = dds[idx] || 0;
      }

      // Trades: sum avg trades for active robots in this window
      let totalTrades = 0;
      for (const r of robots) {
        const avg = robotAverages.get(r.name);
        if (avg) {
          totalTrades += avg.avgTrades * window.length;
        }
      }

      return {
        profit,
        maxDD,
        var95: windowVar95,
        days: window.length,
        months: window.length / 21.5,
        trades: totalTrades
      };
    };

    const recentStats = calculateWindowStats(windowRecent, date12mStr, lastDateStr);
    const pastEndDate = sortedDays.filter(d => d < date12mStr).pop() || date12mStr;
    const pastStats = calculateWindowStats(windowPast, sortedDays[0], pastEndDate);
    
    // Weighted past profit for 12-month normalized comparison
    if (pastStats) {
      (pastStats as any).weightedProfit = (pastStats.profit / (pastStats.months || 1)) * 12;
      (pastStats as any).weightedTrades = (pastStats.trades / (pastStats.months || 1)) * 12;
    }

    // Per-Robot Recent Stats (Last 12m)
    const robotRecentStats: any = {};
    for (const r of robots) {
      const r_daily = robotDailyData.get(r.name);
      if (!r_daily) continue;
      
      const r_window = sortedDays
        .filter(d => d >= date12mStr && r_daily.has(d))
        .map(d => r_daily.get(d)!);
      
      if (r_window.length === 0) {
        robotRecentStats[r.name] = { profit: 0, maxDD: 0, var95: 0, lots: 0, ddContribution: 0 };
        continue;
      }

      const startP = r_window[0].profit;
      const endP = r_window[r_window.length - 1].profit;
      const profit = (endP - startP) * r.weight;

      let maxDD = 0;
      r_window.forEach(pt => {
        const dd = pt.dd * r.weight;
        if (dd > maxDD) maxDD = dd;
      });

      // VaR 95% (Robot level): 95th percentile of robot drawdown series
      let rVar95 = 0;
      if (r_window.length > 5) {
        const dds = r_window.map(pt => pt.dd * r.weight).sort((a,b) => a - b);
        const idx = Math.floor(dds.length * 0.95);
        rVar95 = dds[idx] || 0;
      }

      // Lots: Approximate based on average and window length, scaled by weight
      const monthsInWindow = r_window.length / 21;
      const lots = r.lots_per_month * r.weight * monthsInWindow;

      robotRecentStats[r.name] = {
        profit,
        maxDD,
        ddContribution: maxDD,
        var95: rVar95,  // VaR in $ value
        lots
      };
    }

    // Pearson Correlation
    const calculatePearson = (serA: number[], serB: number[]) => {
      const n = serA.length;
      if (n < 2) return 0;
      const meanA = serA.reduce((s, v) => s + v, 0) / n;
      const meanB = serB.reduce((s, v) => s + v, 0) / n;
      let num = 0, denA = 0, denB = 0;
      for (let i = 0; i < n; i++) {
        num += (serA[i] - meanA) * (serB[i] - meanB);
        denA += (serA[i] - meanA) ** 2;
        denB += (serB[i] - meanB) ** 2;
      }
      return denA && denB ? num / Math.sqrt(denA * denB) : 0;
    };

    const correlation: any = {};
    const rNames = [...robotDailyDD.keys()];
    for (const nA of rNames) {
      correlation[nA] = {};
      const mapA = robotDailyDD.get(nA)!;
      for (const nB of rNames) {
        if (nA === nB) correlation[nA][nB] = 1;
        else {
          const mapB = robotDailyDD.get(nB)!;
          const common = sortedDays.filter(d => mapA.has(d) && mapB.has(d));
          const vA = common.map(d => mapA.get(d)!);
          const vB = common.map(d => mapB.get(d)!);
          correlation[nA][nB] = parseFloat(calculatePearson(vA, vB).toFixed(3));
        }
      }
    }

    // Prepare stacked data for top 10 DD
    const top10Stacked: any[] = top10DD.map(event => {
      const breakdown: any = { day: event.day, total: event.value };
      for (const r of robots) {
        breakdown[r.name] = robotDailyDD.get(r.name)?.get(event.day) || 0;
      }
      return breakdown;
    });

    // Robot performance curves (daily weighted profit)
    const robotCurves: any = {};
    for (const r of robots) {
      let lastState = { profit: 0, balanceProfit: 0, dd: 0 };
      robotCurves[r.name] = sortedDays.map(day => {
        const d = robotDailyData.get(r.name)?.get(day);
        if (d) lastState = d;
        return {
          day,
          profit: lastState.profit * (r.weight || 1),
          balanceProfit: lastState.balanceProfit * (r.weight || 1),
          dd: lastState.dd * (r.weight || 1)
        };
      }).filter((_, i) => i % Math.max(1, Math.floor(sortedDays.length / 400)) === 0);
    }

    // 4. Calculate monthly returns table (Year x Month: profit $, return %, DME $)
    const monthlyDataMap = new Map<string, { year: number, month: number, startBalanceProfit: number, endBalanceProfit: number, maxDD: number }>();
    
    // Iterate over combinedCurve to group by year and month
    combinedCurve.forEach((pt, idx) => {
      const parts = pt.day.split(/[-.]/); // YYYY-MM-DD or YYYY.MM.DD
      if (parts.length < 2) return;
      const yr = parseInt(parts[0], 10);
      const mo = parseInt(parts[1], 10);
      if (isNaN(yr) || isNaN(mo)) return;
      const key = `${yr}-${mo}`;

      if (!monthlyDataMap.has(key)) {
        // Start balance profit is previous point's balanceProfit or first point's balanceProfit
        const prevPt = idx > 0 ? combinedCurve[idx - 1] : pt;
        monthlyDataMap.set(key, {
          year: yr,
          month: mo,
          startBalanceProfit: prevPt.balanceProfit,
          endBalanceProfit: pt.balanceProfit,
          maxDD: pt.dd
        });
      } else {
        const item = monthlyDataMap.get(key)!;
        item.endBalanceProfit = pt.balanceProfit;
        if (pt.dd > item.maxDD) item.maxDD = pt.dd;
      }
    });

    // Structure into array of years sorted descending
    const yearsSet = new Set<number>();
    monthlyDataMap.forEach(v => yearsSet.add(v.year));
    const sortedYears = Array.from(yearsSet).sort((a, b) => b - a);

    const monthlyReturns = sortedYears.map(year => {
      const months: { [m: number]: { profit: number, pct: number, dme: number } } = {};
      let totalYearProfit = 0;
      let maxYearDD = 0;

      for (let m = 1; m <= 12; m++) {
        const key = `${year}-${m}`;
        if (monthlyDataMap.has(key)) {
          const item = monthlyDataMap.get(key)!;
          const profit = item.endBalanceProfit - item.startBalanceProfit;
          const pct = pf.capital > 0 ? (profit / pf.capital) * 100 : 0;
          const dme = item.maxDD;
          months[m] = { profit, pct, dme };
          totalYearProfit += profit;
          if (dme > maxYearDD) maxYearDD = dme;
        }
      }

      const totalYearPct = pf.capital > 0 ? (totalYearProfit / pf.capital) * 100 : 0;
      return {
        year,
        months,
        yearTotal: {
          profit: totalYearProfit,
          pct: totalYearPct,
          dme: maxYearDD
        }
      };
    });

    const firstGlobalDay = sortedDays[0];
    const lastGlobalDay = sortedDays[sortedDays.length - 1];

    res.json({
      portfolio: pf,
      robots: robots.map(({ equity_curve: _e, ...rest }) => {
        const avg = robotAverages.get(rest.name);
        const isIncomplete = avg ? (avg.firstDay > firstGlobalDay || avg.lastDay < lastGlobalDay) : false;
        return {
          ...rest,
          has_incomplete_data: isIncomplete,
          monthly_drawdown: rest.monthly_drawdown ? JSON.parse(rest.monthly_drawdown) : [],
          ll_dd_pct: Number(rest.max_dd_from_csv || rest.max_dd_equity || 0) > 0 ? (rest.avg_profit_per_month / (rest.max_dd_from_csv || rest.max_dd_equity)) * 100 : 0
        };
      }),
      totals: {
        lucroMes: totalProfitMes,
        roiMes,
        roiDiaCash,
        ddMaxPortfolio,
        ddMaxPct,
        dme: (pf.manual_dme !== null && pf.manual_dme !== undefined && pf.manual_dme !== 0) ? pf.manual_dme : ddMaxPortfolio,
        var95, 
        sharpe: avgSharpe,
        llDdPct,
        somaIndividualDD,
        recent: recentStats,
        past: pastStats,
        robotRecent: robotRecentStats
      },
      combined_curve: combinedCurve.filter((_, i) => i % Math.max(1, Math.floor(combinedCurve.length / 400)) === 0),
      robot_curves: robotCurves,
      top10DD: top10Stacked,
      monthly_returns: monthlyReturns,
      correlation
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: String(err) });
  }
});

// POST /api/portfolios/:id/optimize-weights — Auto-optimize robot weights using LL/DD maximization with correlation penalization
app.post('/api/portfolios/:id/optimize-weights', async (req, res) => {
  try {
    const db = await getDb();
    const pf = await db.get(`SELECT * FROM portfolios WHERE id = ?`, [req.params.id]);
    if (!pf) return res.status(404).json({ error: 'Portfolio not found' });

    const robots = await db.all(`
      SELECT pr.weight, pr.robot_id,
        r.name, r.asset, r.timeframe, r.avg_profit_per_month,
        r.max_dd_from_csv, r.max_dd_equity, r.profit_factor, r.sharpe_ratio,
        r.total_months, r.equity_curve, r.total_trades,
        r.total_lots, r.lots_per_month, r.var_95_dd_cap, r.initial_deposit
      FROM portfolio_robots pr
      JOIN robots r ON r.id = pr.robot_id
      WHERE pr.portfolio_id = ?
    `, [req.params.id]);

    if (robots.length === 0) {
      return res.json({ suggestions: [], comparison: null, message: 'Nenhum robô no portfólio.' });
    }
    if (robots.length === 1) {
      return res.json({
        suggestions: [{
          robot_id: robots[0].robot_id,
          name: robots[0].name,
          asset: robots[0].asset,
          current_weight: robots[0].weight,
          suggested_weight: robots[0].weight,
          score: 1,
          reason: 'Único robô — peso mantido'
        }],
        comparison: null,
        message: 'Apenas 1 robô, otimização requer 2+.'
      });
    }

    // 1. Build daily DD, profit and combined data for correlation + combined curve
    const robotDailyData: Map<string, Map<string, { profit: number, dd: number }>> = new Map();
    const robotDailyDD: Map<string, Map<string, number>> = new Map();
    const robotDailyProfit: Map<string, Map<string, number>> = new Map();
    const allGlobalDays: Set<string> = new Set();

    for (const r of robots) {
      const curve = JSON.parse(r.equity_curve || '[]');
      if (curve.length === 0) continue;
      const effectiveInitial = curve[0].equity;
      let robotPeak = effectiveInitial;
      const ddMap: Map<string, number> = new Map();
      const profitMap: Map<string, number> = new Map();
      const dailyMap: Map<string, { profit: number, dd: number }> = new Map();
      curve.forEach((pt: any) => {
        const day = pt.date ? pt.date.split(' ')[0] : (pt.timestamp ? pt.timestamp.split(' ')[0] : '2020-01-01');
        if (pt.equity > robotPeak) robotPeak = pt.equity;
        const curDD = robotPeak - pt.equity;
        const profit = pt.equity - effectiveInitial;
        allGlobalDays.add(day);
        // Keep max DD and latest profit of the day
        if (!ddMap.has(day) || curDD > ddMap.get(day)!) {
          ddMap.set(day, curDD);
        }
        profitMap.set(day, profit);
        if (!dailyMap.has(day)) {
          dailyMap.set(day, { profit, dd: curDD });
        } else {
          const g = dailyMap.get(day)!;
          g.profit = profit;
          if (curDD > g.dd) g.dd = curDD;
        }
      });
      robotDailyData.set(r.name, dailyMap);
      robotDailyDD.set(r.name, ddMap);
      robotDailyProfit.set(r.name, profitMap);
    }

    const sortedDays = Array.from(allGlobalDays).sort();

    // 2. Calculate Pearson correlation between robots (on DD series)
    const calculatePearson = (serA: number[], serB: number[]) => {
      const n = serA.length;
      if (n < 2) return 0;
      const meanA = serA.reduce((s, v) => s + v, 0) / n;
      const meanB = serB.reduce((s, v) => s + v, 0) / n;
      let num = 0, denA = 0, denB = 0;
      for (let i = 0; i < n; i++) {
        num += (serA[i] - meanA) * (serB[i] - meanB);
        denA += (serA[i] - meanA) ** 2;
        denB += (serB[i] - meanB) ** 2;
      }
      return denA && denB ? num / Math.sqrt(denA * denB) : 0;
    };

    const rNames = robots.map(r => r.name);
    const corrMatrix: { [a: string]: { [b: string]: number } } = {};
    for (const nA of rNames) {
      corrMatrix[nA] = {};
      const mapA = robotDailyDD.get(nA);
      for (const nB of rNames) {
        if (nA === nB) { corrMatrix[nA][nB] = 1; continue; }
        const mapB = robotDailyDD.get(nB);
        if (!mapA || !mapB) { corrMatrix[nA][nB] = 0; continue; }
        const common = sortedDays.filter(d => mapA.has(d) && mapB.has(d));
        const vA = common.map(d => mapA.get(d)!);
        const vB = common.map(d => mapB.get(d)!);
        corrMatrix[nA][nB] = calculatePearson(vA, vB);
      }
    }

    // 3. Score each robot: LL/DD efficiency × correlation penalty
    const scores: { robot: any, score: number, baseScore: number, avgCorr: number, reason: string }[] = [];

    for (const r of robots) {
      const dd = Number(r.max_dd_from_csv || r.max_dd_equity || 1);
      const profit = Number(r.avg_profit_per_month || 0);
      const baseScore = dd > 0 ? profit / dd : 0;

      // Average absolute correlation with other robots
      const otherCorrs = rNames
        .filter(n => n !== r.name)
        .map(n => Math.abs(corrMatrix[r.name]?.[n] || 0));
      const avgCorr = otherCorrs.length > 0 ? otherCorrs.reduce((s, v) => s + v, 0) / otherCorrs.length : 0;

      // Penalize high correlation: score × (1 - avgCorr × 0.5)
      const corrPenalty = 1 - avgCorr * 0.5;
      const finalScore = Math.max(0, baseScore * corrPenalty);

      let reason = '';
      if (baseScore > 0.5 && avgCorr < 0.3) reason = 'Alto LL/DD, baixa correlação ✓';
      else if (baseScore > 0.5 && avgCorr >= 0.3) reason = 'Alto LL/DD, correlação moderada';
      else if (baseScore > 0.2 && avgCorr < 0.3) reason = 'LL/DD médio, boa diversificação';
      else if (baseScore > 0.2) reason = 'LL/DD médio, correlação alta';
      else if (avgCorr < 0.3) reason = 'LL/DD baixo, boa diversificação';
      else reason = 'LL/DD baixo, alta correlação ⚠';

      scores.push({ robot: r, score: finalScore, baseScore, avgCorr, reason });
    }

    // 4. Normalize scores into weights
    const totalScore = scores.reduce((s, sc) => s + sc.score, 0);
    if (totalScore === 0) {
      const equalWeight = 1;
      return res.json({
        suggestions: scores.map(sc => ({
          robot_id: sc.robot.robot_id,
          name: sc.robot.name,
          asset: sc.robot.asset,
          current_weight: sc.robot.weight,
          suggested_weight: equalWeight,
          score: 0,
          baseScore: sc.baseScore,
          avgCorr: sc.avgCorr,
          reason: 'Score zero — pesos iguais'
        })),
        comparison: null,
        message: 'Todos os robôs têm score 0. Sugeridos pesos iguais.'
      });
    }

    // Scale: The robot with highest score gets the highest weight
    const minScore = Math.min(...scores.filter(s => s.score > 0).map(s => s.score));

    // Raw proportional weights (minimum 1)
    let rawWeights = scores.map(sc => ({
      ...sc,
      rawWeight: sc.score > 0 ? Math.max(1, sc.score / minScore) : 1
    }));

    // Helper: Calculate DD Max Portf. (exactly matching stats endpoint ddMaxPortfolio)
    const calcDDMaxPortf = (weightMap: Map<string, number>): number => {
      const lastKnown = new Map<string, { profit: number, dd: number }>();
      for (const r of robots) lastKnown.set(r.name, { profit: 0, dd: 0 });

      let maxDD = 0;

      for (const day of sortedDays) {
        let totalSumDD = 0;

        for (const r of robots) {
          const weight = weightMap.get(r.robot_id) ?? (r.weight || 1);
          const lk = lastKnown.get(r.name)!;
          let dd = lk.dd;

          const dayData = robotDailyData.get(r.name)?.get(day);
          if (dayData) {
            dd = dayData.dd;
            lastKnown.set(r.name, { profit: dayData.profit, dd });
          }

          totalSumDD += dd * weight;
        }

        if (totalSumDD > maxDD) maxDD = totalSumDD;
      }
      return maxDD;
    };

    // Calculate DD Max Portf. with current weights
    const currentWeightMap = new Map<string, number>();
    robots.forEach(r => currentWeightMap.set(r.robot_id, r.weight));
    const currentDDMaxPortf = calcDDMaxPortf(currentWeightMap);

    // Apply DD target constraint using DD Max Portf.
    const targetDD = Number(pf.target_dd) || 5000;

    // First pass: compute DD with raw weights to check if we need to scale down
    const rawWeightMap = new Map<string, number>();
    rawWeights.forEach(rw => rawWeightMap.set(rw.robot.robot_id, Math.max(1, Math.round(rw.rawWeight))));
    const rawDDMaxPortf = calcDDMaxPortf(rawWeightMap);

    let scaleFactor = 1;
    if (rawDDMaxPortf > targetDD && rawDDMaxPortf > 0) {
      scaleFactor = targetDD / rawDDMaxPortf;
    }

    // Apply scale and round to integers (min 1)
    const suggestions = rawWeights.map(rw => {
      const scaled = rw.rawWeight * scaleFactor;
      const rounded = Math.max(1, Math.round(scaled));
      return {
        robot_id: rw.robot.robot_id,
        name: rw.robot.name,
        asset: rw.robot.asset,
        current_weight: rw.robot.weight,
        suggested_weight: rounded,
        score: parseFloat(rw.score.toFixed(3)),
        baseScore: parseFloat(rw.baseScore.toFixed(3)),
        avgCorr: parseFloat(rw.avgCorr.toFixed(3)),
        reason: rw.reason
      };
    });

    // 5. Calculate comparison metrics using DD Max Portf. (combined curve)
    const currentLucroMes = robots.reduce((s, r) => s + r.avg_profit_per_month * r.weight, 0);
    const currentLLDD = currentDDMaxPortf > 0 ? (currentLucroMes / currentDDMaxPortf) * 100 : 0;
    const currentROI = pf.capital > 0 ? (currentLucroMes / pf.capital) * 100 : 0;

    const optimizedWeightMap = new Map<string, number>();
    suggestions.forEach(sg => optimizedWeightMap.set(sg.robot_id, sg.suggested_weight));
    const optimizedDDMaxPortf = calcDDMaxPortf(optimizedWeightMap);

    const optimizedLucroMes = suggestions.reduce((s, sg) => {
      const r = robots.find(r => r.robot_id === sg.robot_id)!;
      return s + r.avg_profit_per_month * sg.suggested_weight;
    }, 0);
    const optimizedLLDD = optimizedDDMaxPortf > 0 ? (optimizedLucroMes / optimizedDDMaxPortf) * 100 : 0;
    const optimizedROI = pf.capital > 0 ? (optimizedLucroMes / pf.capital) * 100 : 0;

    res.json({
      suggestions,
      comparison: {
        current: {
          lucroMes: parseFloat(currentLucroMes.toFixed(2)),
          ddMaxPortf: parseFloat(currentDDMaxPortf.toFixed(2)),
          llDd: parseFloat(currentLLDD.toFixed(2)),
          roi: parseFloat(currentROI.toFixed(2))
        },
        optimized: {
          lucroMes: parseFloat(optimizedLucroMes.toFixed(2)),
          ddMaxPortf: parseFloat(optimizedDDMaxPortf.toFixed(2)),
          llDd: parseFloat(optimizedLLDD.toFixed(2)),
          roi: parseFloat(optimizedROI.toFixed(2))
        }
      }
    });
  } catch (err) {
    console.error('Error optimizing weights:', err);
    res.status(500).json({ error: String(err) });
  }
});

// GET /api/portfolios/:id/export-nautilus - Export Excel (.xlsx) for Portfolio with native tables and charts
app.get('/api/portfolios/:id/export-nautilus', async (req, res) => {
  try {
    const db = await getDb();
    const pf = await db.get(`SELECT * FROM portfolios WHERE id = ?`, [req.params.id]);
    if (!pf) return res.status(404).send('Portfolio not found');

    const robots = await db.all(`
      SELECT pr.weight, pr.robot_id,
        r.name, r.asset, r.timeframe, r.avg_profit_per_month, r.initial_deposit,
        r.max_dd_from_csv, r.max_dd_equity, r.profit_factor, r.sharpe_ratio,
        r.total_months, r.monthly_drawdown, r.equity_curve, r.total_trades,
        r.total_lots, r.lots_per_month, r.var_95_dd_cap
      FROM portfolio_robots pr
      JOIN robots r ON r.id = pr.robot_id
      WHERE pr.portfolio_id = ?
    `, [req.params.id]);

    // 1. Calculate daily timeline & stats
    const robotDailyData: Map<string, Map<string, { profit: number, dd: number, balanceProfit: number }>> = new Map();
    const allGlobalDays: Set<string> = new Set();

    for (const r of robots) {
      const curve = JSON.parse(r.equity_curve || '[]');
      if (curve.length === 0) continue;

      const effectiveInitial = curve[0].equity;
      let robotPeak = effectiveInitial;
      const r_daily_group: Map<string, { profit: number, dd: number, balanceProfit: number }> = new Map();
      let lastBalanceProfit = 0;
      curve.forEach((pt: any) => {
        const day = pt.date ? pt.date.split(' ')[0] : (pt.timestamp ? pt.timestamp.split(' ')[0] : '2020-01-01');
        if (pt.equity > robotPeak) robotPeak = pt.equity;
        const curDD = (robotPeak - pt.equity);
        const profit = pt.equity - effectiveInitial;
        if (pt.balance !== undefined) lastBalanceProfit = pt.balance - effectiveInitial;

        allGlobalDays.add(day);
        if (!r_daily_group.has(day)) {
          r_daily_group.set(day, { profit, dd: curDD, balanceProfit: lastBalanceProfit });
        } else {
          const g = r_daily_group.get(day)!;
          g.profit = profit;
          g.balanceProfit = lastBalanceProfit;
          if (curDD > g.dd) g.dd = curDD;
        }
      });
      robotDailyData.set(r.name, r_daily_group);
    }

    const sortedDays = Array.from(allGlobalDays).sort();
    const lastKnown = new Map<string, { profit: number, balanceProfit: number, dd: number }>();
    for (const r of robots) lastKnown.set(r.name, { profit: 0, balanceProfit: 0, dd: 0 });

    const combinedCurve: any[] = [];
    for (const day of sortedDays) {
      let totalProfit = 0;
      let totalBalanceProfit = 0;
      let totalSumDD = 0;

      for (const r of robots) {
        const weight = r.weight || 1;
        const lk = lastKnown.get(r.name)!;
        let profit = lk.profit;
        let balanceProfit = lk.balanceProfit;
        let dd = lk.dd;

        const dayData = robotDailyData.get(r.name)?.get(day);
        if (dayData) {
          profit = dayData.profit;
          balanceProfit = dayData.balanceProfit;
          dd = dayData.dd;
          lastKnown.set(r.name, { profit, balanceProfit, dd });
        }

        totalProfit += profit * weight;
        totalBalanceProfit += balanceProfit * weight;
        totalSumDD += dd * weight;
      }

      combinedCurve.push({
        day,
        profit: totalProfit,
        balanceProfit: totalBalanceProfit,
        equity: pf.capital + totalBalanceProfit,
        dd: totalSumDD
      });
    }

    // Calculate Monthly Returns table
    const monthlyDataMap = new Map<string, { year: number, month: number, startBalanceProfit: number, endBalanceProfit: number, maxDD: number }>();
    combinedCurve.forEach((pt, idx) => {
      const parts = pt.day.split(/[-.]/);
      if (parts.length < 2) return;
      const yr = parseInt(parts[0], 10);
      const mo = parseInt(parts[1], 10);
      if (isNaN(yr) || isNaN(mo)) return;
      const key = `${yr}-${mo}`;

      if (!monthlyDataMap.has(key)) {
        const prevPt = idx > 0 ? combinedCurve[idx - 1] : pt;
        monthlyDataMap.set(key, { year: yr, month: mo, startBalanceProfit: prevPt.balanceProfit, endBalanceProfit: pt.balanceProfit, maxDD: pt.dd });
      } else {
        const item = monthlyDataMap.get(key)!;
        item.endBalanceProfit = pt.balanceProfit;
        if (pt.dd > item.maxDD) item.maxDD = pt.dd;
      }
    });

    const yearsSet = new Set<number>();
    monthlyDataMap.forEach(v => yearsSet.add(v.year));
    const sortedYears = Array.from(yearsSet).sort((a, b) => b - a);

    // Create Excel Workbook
    const workbook = new ExcelJS.Workbook();
    workbook.creator = 'DATA_LAB Nautilus';
    workbook.created = new Date();

    // ── SHEET 1: RESUMO DO FUNDO (Tables & Summary) ──────────────────
    const wsSummary = workbook.addWorksheet('Resumo Portfólio');

    // Header Title
    wsSummary.getCell('A1').value = `DATA_LAB Nautilus — RELATÓRIO DO PORTFÓLIO: ${pf.name.toUpperCase()}`;
    wsSummary.getCell('A1').font = { name: 'Arial', size: 14, bold: true, color: { argb: 'FF002060' } };
    wsSummary.getCell('A2').value = `Capital Inicial: R$ ${pf.capital.toLocaleString('pt-BR', { minimumFractionDigits: 2 })} | Data de Geração: ${new Date().toLocaleString('pt-BR')}`;
    wsSummary.getCell('A2').font = { name: 'Arial', size: 10, italic: true, color: { argb: 'FF595959' } };

    // Section 1: Robôs do Portfólio
    wsSummary.getCell('A4').value = '1. ROBÔS ALOCADOS NO PORTFÓLIO';
    wsSummary.getCell('A4').font = { name: 'Arial', size: 11, bold: true };

    const robotHeaders = ['Nome do Robô', 'Ativo', 'Timeframe', 'Peso', 'Lucro Mês (R$)', 'DD Máx (R$)', 'Retorno Mês (%)'];
    wsSummary.getRow(5).values = robotHeaders;
    wsSummary.getRow(5).font = { bold: true, color: { argb: 'FFFFFFFF' } };
    wsSummary.getRow(5).eachCell(cell => {
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1F4E79' } };
      cell.alignment = { horizontal: 'center', vertical: 'middle' };
    });

    let currentBaseline = 6;
    robots.forEach(r => {
      const row = wsSummary.getRow(currentBaseline);
      const profitMonth = (r.avg_profit_per_month || 0) * (r.weight || 1);
      const ddMax = (r.max_dd_from_csv || r.max_dd_equity || 0) * (r.weight || 1);
      const returnPct = pf.capital > 0 ? (profitMonth / pf.capital) * 100 : 0;

      row.values = [r.name, r.asset || '-', r.timeframe || '-', r.weight || 1, profitMonth, ddMax, returnPct / 100];
      row.getCell(4).alignment = { horizontal: 'center' };
      row.getCell(5).numFmt = 'R$ #,##0.00';
      row.getCell(6).numFmt = 'R$ #,##0.00';
      row.getCell(7).numFmt = '0.00%';
      currentBaseline++;
    });

    // Section 2: Rentabilidade Histórica Mensal
    currentBaseline += 2;
    wsSummary.getCell(`A${currentBaseline}`).value = '2. RENTABILIDADE HISTÓRICA MENSAL (% CAPITAL / LUCRO R$)';
    wsSummary.getCell(`A${currentBaseline}`).font = { name: 'Arial', size: 11, bold: true };
    currentBaseline++;

    const monthNames = ['Ano', 'Métrica', 'Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez', 'No Ano'];
    wsSummary.getRow(currentBaseline).values = monthNames;
    wsSummary.getRow(currentBaseline).font = { bold: true, color: { argb: 'FFFFFFFF' } };
    wsSummary.getRow(currentBaseline).eachCell(cell => {
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1F4E79' } };
      cell.alignment = { horizontal: 'center' };
    });
    currentBaseline++;

    sortedYears.forEach(year => {
      let totalYearProfit = 0;
      let maxYearDME = 0;
      const monthRowPctValues: (string | number)[] = [year, '% Capital'];
      const monthRowProfitValues: (string | number)[] = ['', 'Lucro R$'];
      const monthRowDmeValues: (string | number)[] = ['', 'DME R$'];

      for (let m = 1; m <= 12; m++) {
        const key = `${year}-${m}`;
        if (monthlyDataMap.has(key)) {
          const item = monthlyDataMap.get(key)!;
          const profit = item.endBalanceProfit - item.startBalanceProfit;
          const pct = pf.capital > 0 ? profit / pf.capital : 0;
          const dme = item.maxDD;

          monthRowPctValues.push(pct);
          monthRowProfitValues.push(profit);
          monthRowDmeValues.push(dme);

          totalYearProfit += profit;
          if (dme > maxYearDME) maxYearDME = dme;
        } else {
          monthRowPctValues.push('-');
          monthRowProfitValues.push('-');
          monthRowDmeValues.push('-');
        }
      }
      monthRowPctValues.push(pf.capital > 0 ? totalYearProfit / pf.capital : 0);
      monthRowProfitValues.push(totalYearProfit);
      monthRowDmeValues.push(maxYearDME);

      // Row 1: % Capital
      const rPct = wsSummary.getRow(currentBaseline);
      rPct.values = monthRowPctValues;
      rPct.font = { bold: true };
      for (let c = 3; c <= 15; c++) {
        if (typeof rPct.getCell(c).value === 'number') {
          rPct.getCell(c).numFmt = '0.00%';
        }
        rPct.getCell(c).alignment = { horizontal: 'center' };
      }
      currentBaseline++;

      // Row 2: Profit R$
      const rProf = wsSummary.getRow(currentBaseline);
      rProf.values = monthRowProfitValues;
      for (let c = 3; c <= 15; c++) {
        if (typeof rProf.getCell(c).value === 'number') {
          rProf.getCell(c).numFmt = 'R$ #,##0.00';
        }
        rProf.getCell(c).alignment = { horizontal: 'center' };
      }
      currentBaseline++;

      // Row 3: DME R$
      const rDme = wsSummary.getRow(currentBaseline);
      rDme.values = monthRowDmeValues;
      rDme.font = { italic: true, color: { argb: 'FFC00000' } };
      for (let c = 3; c <= 15; c++) {
        if (typeof rDme.getCell(c).value === 'number') {
          rDme.getCell(c).numFmt = 'R$ #,##0.00';
        }
        rDme.getCell(c).alignment = { horizontal: 'center' };
      }
      currentBaseline += 2;
    });

    // Adjust column widths
    wsSummary.columns.forEach(col => { col.width = 16; });
    wsSummary.getColumn(1).width = 35;

    // ── SHEET 2: HISTÓRICO E GRÁFICO (Chart Sheet) ───────────────────
    const wsCurve = workbook.addWorksheet('Curva de Patrimônio');

    wsCurve.getRow(1).values = ['Data', 'Lucro Acumulado (R$)', 'Patrimônio Total (R$)', 'Drawdown Intraday (R$)'];
    wsCurve.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
    wsCurve.getRow(1).eachCell(cell => {
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1F4E79' } };
      cell.alignment = { horizontal: 'center' };
    });

    combinedCurve.forEach((pt, idx) => {
      const row = wsCurve.getRow(idx + 2);
      row.values = [pt.day, pt.balanceProfit, pt.equity, pt.dd];
      row.getCell(2).numFmt = 'R$ #,##0.00';
      row.getCell(3).numFmt = 'R$ #,##0.00';
      row.getCell(4).numFmt = 'R$ #,##0.00';
    });

    wsCurve.columns.forEach(col => { col.width = 24; });

    // Dados organizados para gráfico no Excel


    // ── SHEET 3: DADOS DIÁRIOS ROBÔS (Nautilus Export) ───────────────
    const wsDaily = workbook.addWorksheet('Dados Diários Robôs');
    wsDaily.getRow(1).values = ['robo', 'data', 'lucro', 'DD Max'];
    wsDaily.getRow(1).font = { bold: true };

    let dailyRowIndex = 2;
    for (const r of robots) {
      const curve = JSON.parse(r.equity_curve || '[]');
      const initial = r.initial_deposit || 10000;
      const weight = r.weight || 1;

      const dailyData: Map<string, { points: any[] }> = new Map();
      curve.forEach((pt: any) => {
        const rawDate = pt.date || pt.timestamp || pt.day || '2020.01.01.00.00';
        const day = rawDate.split(' ')[0].replace(/-/g, '.');
        if (!dailyData.has(day)) dailyData.set(day, { points: [] });
        dailyData.get(day)!.points.push(pt);
      });

      const robotDays = Array.from(dailyData.keys()).sort();
      let prevEquity = initial;
      let robotGlobalPeak = initial;

      for (const day of robotDays) {
        const data = dailyData.get(day)!;
        const lastPt = data.points[data.points.length - 1];
        const dailyProfit = (lastPt.equity - prevEquity) * weight;

        let maxDayDD = 0;
        for (const pt of data.points) {
          if (pt.equity > robotGlobalPeak) robotGlobalPeak = pt.equity;
          const currentDD = robotGlobalPeak - pt.equity;
          if (currentDD > maxDayDD) maxDayDD = currentDD;
        }

        const row = wsDaily.getRow(dailyRowIndex++);
        row.values = [r.name, day, Number(dailyProfit.toFixed(2)), Number((maxDayDD * weight).toFixed(2))];
        prevEquity = lastPt.equity;
      }
    }
    wsDaily.columns.forEach(col => { col.width = 22; });

    // Generate buffer & response
    const buffer = await workbook.xlsx.writeBuffer();
    const filename = `Export_Nautilus_${pf.name.replace(/\s+/g, '_')}_${Date.now()}.xlsx`;

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.status(200).send(Buffer.from(buffer));

  } catch (err) {
    console.error(err);
    res.status(500).send(String(err));
  }
});

// Gemini AI Support
const API_KEY = process.env.GEMINI_API_KEY || process.env.GROQ_API_KEY || '';
console.log('Gemini API Key detected:', API_KEY ? `${API_KEY.substring(0, 8)}...` : 'NONE');
const genAI = new GoogleGenerativeAI(API_KEY);
const GEMINI_MODEL = "gemini-3.6-flash";

function formatDailyPerformance(equityCurve: any[]) {
  if (!equityCurve || equityCurve.length === 0) return "Nenhum dado diário disponível.";
  
  const daily: Map<string, { final: number, dd: number, profit: number }> = new Map();
  let peak = 0;

  equityCurve.forEach((pt) => {
    const rawDate = pt.timestamp || pt.date || pt.day || '2000-01-01';
    const day = rawDate.split(' ')[0].replace(/\./g, '-');
    
    if (pt.equity > peak) peak = pt.equity;
    const curDD = peak - pt.equity;

    if (!daily.has(day)) {
      daily.set(day, { final: pt.equity, dd: curDD, profit: 0 });
    } else {
      const g = daily.get(day)!;
      g.final = pt.equity;
      if (curDD > g.dd) g.dd = curDD;
    }
  });

  const dailyArray = Array.from(daily.entries());
  if (dailyArray.length === 0) return "Nenhum dado diário disponível.";

  const firstFinal = dailyArray[0][1].final;

  // 1. COMPACT MONTHLY SUMMARY (Entire History)
  const monthlyMap: Map<string, { final: number, initial: number, maxDD: number }> = new Map();
  dailyArray.forEach(([day, stats]) => {
    const monthKey = day.substring(0, 7); // YYYY-MM
    if (!monthlyMap.has(monthKey)) {
      monthlyMap.set(monthKey, { final: stats.final, initial: stats.final, maxDD: stats.dd });
    } else {
      const m = monthlyMap.get(monthKey)!;
      m.final = stats.final;
      if (stats.dd > m.maxDD) m.maxDD = stats.dd;
    }
  });

  const monthlyLines = ["Ano-Mês,PatrimônioFinal,LucroNoMês,MaxDDNoMês"];
  let prevMonthFinal = firstFinal;
  for (const [month, stats] of monthlyMap) {
    const profit = stats.final - prevMonthFinal;
    monthlyLines.push(`${month},${stats.final.toFixed(2)},${profit.toFixed(2)},${stats.maxDD.toFixed(2)}`);
    prevMonthFinal = stats.final;
  }

  // 2. RECENT DAILY DETAIL (Last 45 trading days)
  const recentDaysCount = 45;
  const recentDays = dailyArray.slice(-recentDaysCount);
  const dailyLines = ["Data,Patrimônio,LucroDiário,LucroAcumulado,MaxDDDiário"];
  
  let prevFinal = firstFinal;
  if (dailyArray.length > recentDaysCount) {
    const dayBeforeIdx = dailyArray.length - recentDaysCount - 1;
    prevFinal = dailyArray[dayBeforeIdx][1].final;
  }

  recentDays.forEach(([day, stats]) => {
    const dayProfit = stats.final - prevFinal;
    const accumProfit = stats.final - firstFinal;
    dailyLines.push(`${day},${stats.final.toFixed(2)},${dayProfit.toFixed(2)},${accumProfit.toFixed(2)},${stats.dd.toFixed(2)}`);
    prevFinal = stats.final;
  });

  return `
--- INÍCIO DO HISTÓRICO MENSAL COMPLETO (Evolução de longo prazo) ---
${monthlyLines.join('\n')}
--- FIM DO HISTÓRICO MENSAL COMPLETO ---

--- INÍCIO DO HISTÓRICO DIÁRIO RECENTE (Últimos ${recentDays.length} dias de negociação para análise detalhada) ---
${dailyLines.join('\n')}
--- FIM DO HISTÓRICO DIÁRIO RECENTE ---
  `;
}

app.get('/api/ia/info/:type/:id', async (req, res) => {
  try {
    const { type, id } = req.params;
    const db = await getDb();

    if (type === 'robot') {
      const r = await db.get(`SELECT * FROM robots WHERE id = ?`, [id]);
      if (!r) return res.status(404).send('Robot not found');
      
      const curve = JSON.parse(r.equity_curve || '[]');
      const dailyText = formatDailyPerformance(curve);
      
      const stats = `
ROBÔ: ${r.name}
ATIVO: ${r.asset}
TIMEFRAME: ${r.timeframe}
BROKER: ${r.broker}
MÉTRICAS CORE:
- Lucro Líquido: ${r.total_net_profit}
- Profit Factor: ${r.profit_factor}
- Sharpe: ${r.sharpe_ratio}
- Max DD: ${r.max_dd_from_csv || r.max_dd_equity} (${r.max_dd_equity_pct}%)
- Win Rate: ${r.win_rate}%
- Trades Totais: ${r.total_trades}

HISTÓRICO DIÁRIO:
${dailyText}
      `;
      res.json({ context: stats });

    } else if (type === 'portfolio') {
      // Para portfólio, pegamos os dados já agregados (ou geramos)
      const pf = await db.get(`SELECT * FROM portfolios WHERE id = ?`, [id]);
      if (!pf) return res.status(404).send('Portfolio not found');

      // Reutiliza lógica de cálculo de curva combinada (idealmente estaria em uma função pura, mas vamos repetir aqui para rapidez)
      const robots = await db.all(`
        SELECT pr.weight, r.name, r.equity_curve, r.initial_deposit
        FROM portfolio_robots pr JOIN robots r ON r.id = pr.robot_id
        WHERE pr.portfolio_id = ?
      `, [id]);

      const allGlobalDays: Set<string> = new Set();
      const robotDailyData: Map<string, Map<string, { profit: number, dd: number }>> = new Map();

      for (const r of robots) {
        const curve = JSON.parse(r.equity_curve || '[]');
        if (curve.length === 0) continue;
        const effectiveInitial = curve[0].equity;
        let peak = effectiveInitial;
        const r_daily: Map<string, { profit: number, dd: number }> = new Map();
        curve.forEach((pt: any) => {
          const day = (pt.date || pt.timestamp).split(' ')[0].replace(/\./g, '-');
          if (pt.equity > peak) peak = pt.equity;
          const dd = peak - pt.equity;
          allGlobalDays.add(day);
          if (!r_daily.has(day)) r_daily.set(day, { profit: pt.equity - effectiveInitial, dd });
          else {
            const g = r_daily.get(day)!;
            g.profit = pt.equity - effectiveInitial;
            if (dd > g.dd) g.dd = dd;
          }
        });
        robotDailyData.set(r.name, r_daily);
      }

      const sorted = Array.from(allGlobalDays).sort();
      const currentState: Map<string, { profit: number, dd: number }> = new Map();
      const combined: any[] = [];
      for (const day of sorted) {
        let tProfit = 0, tDD = 0;
        for (const r of robots) {
          if (robotDailyData.get(r.name)?.has(day)) currentState.set(r.name, robotDailyData.get(r.name)!.get(day)!);
          const s = currentState.get(r.name) || { profit: 0, dd: 0 };
          tProfit += s.profit * (r.weight || 1);
          tDD += s.dd * (r.weight || 1);
        }
        combined.push({ day, equity: (pf.capital || 30000) + tProfit, dd: tDD });
      }

      const dailyText = formatDailyPerformance(combined);
      const context = `
PORTFÓLIO: ${pf.name}
CAPITAL INICIAL: ${pf.capital}
ROBÔS COMPONENTES: ${robots.map(r => `${r.name} (Peso: ${r.weight})`).join(', ')}

HISTÓRICO DIÁRIO COMBINADO:
${dailyText}
      `;
      res.json({ context });
    }
  } catch (err) { res.status(500).send(String(err)); }
});

// Import strategy parser helpers
import { parseSetContent, parseHtmlBacktest, buildStrategyPromptContext } from './strategy_parser';

// ── STRATEGY AI STUDIO ENDPOINTS ─────────────────────────────
app.post('/api/ia/strategy-analyze', async (req, res) => {
  try {
    const { robotName, setContent, htmlContent, mqlCode, docText, userRational } = req.body;

    let parsedSet = undefined;
    if (setContent) {
      parsedSet = parseSetContent(setContent);
    }

    let backtestMetrics = undefined;
    if (htmlContent) {
      backtestMetrics = parseHtmlBacktest(htmlContent);
    }

    const context = buildStrategyPromptContext({
      robotName,
      parsedSet,
      backtestMetrics,
      mqlCode,
      docText,
      userRational
    });

    res.json({
      success: true,
      context,
      parsedSet,
      backtestMetrics
    });
  } catch (err: any) {
    console.error('Error analyzing strategy:', err);
    res.status(500).json({ error: 'Erro ao processar arquivos da estratégia', details: err?.message || String(err) });
  }
});

app.post('/api/ia/strategy-chat', async (req, res) => {
  try {
    const { messages, context } = req.body;

    const apiKey = process.env.GEMINI_API_KEY || process.env.GROQ_API_KEY;
    if (!apiKey) {
      return res.status(400).json({ error: 'A chave Gemini (GEMINI_API_KEY) não foi configurada no servidor.' });
    }

    const systemPrompt = `Você é o Nautilus Quant Architect & Strategy Engineer de elite.
Sua especialidade é engenharia reversa de estratégias de trading algorítmico, análise de código MQL5 / Python, cálculo de risco/drawdown e desenho de hedges e transposições de ativos.

ESTRUTURA OBRIGATÓRIA DE TRABALHO:
1. Quando solicitado a analisar uma estratégia pela primeira vez, forneça:
   - Raio-X Técnico (Ativo, Timeframe, Direção, Gatilhos de Entrada, Manejo de Stop/Take Profit, Grid/Lotes).
   - Racional Operacional Completo (A tese de mercado por trás da estratégia e por que ela funciona).
   - Ponto Cego / Vetores de Risco de Drawdown.
   - Solicitação de Validação / Ajuste com o Usuário.
2. Quando solicitado a criar um HEDGE:
   - Explique o modelo de contra-posição (ex: Breakout reverso, Mean Reversion em baixa volatilidade, correlação cambial/índice).
   - Defina gatilhos matemáticos exatos de ativação e saída.
3. Quando solicitado a TRANSPOR O ATIVO (ex: Nasdaq -> EURUSD ou WIN -> WDO):
   - Mapeie cada parâmetro do .set explicando o ajuste de volatilidade (pips/ticks), horários de liquidez e direção.
4. Quando solicitado a GERAR A DEVOLUTIVA TÉCNICA / MARKDOWN:
   - Gere um documento Markdown completo, estruturado e auto-suficiente com inputs em MQL5/Python, máquina de estados e regras operacionais para ser construído diretamente no Antigravity.

CONTEXTO DA ESTRATÉGIA CARREGADA:
${context}`;

    const geminiInstance = new GoogleGenerativeAI(apiKey);
    const geminiModel = geminiInstance.getGenerativeModel({
      model: GEMINI_MODEL,
      systemInstruction: systemPrompt,
      generationConfig: {
        temperature: 0.2,
        maxOutputTokens: 4096,
      }
    });

    // Format history for Gemini SDK: role 'user' | 'model'
    const contents = messages.map((m: any) => ({
      role: m.role === 'assistant' || m.role === 'model' ? 'model' : 'user',
      parts: Array.isArray(m.parts) 
        ? m.parts 
        : [{ text: typeof m.content === 'string' ? m.content : (m.parts?.[0]?.text || '') }]
    }));

    const result = await geminiModel.generateContent({ contents });
    const responseText = result.response.text();

    res.json({ text: responseText });
  } catch (err: any) {
    console.error('Gemini Strategy Chat Error:', err?.message || err);
    res.status(500).json({ 
      error: 'Erro na comunicação com a IA (Gemini)', 
      details: err?.message || String(err) 
    });
  }
});

app.post('/api/ia/chat', async (req, res) => {
  try {
    const { messages, context } = req.body; 
    
    const apiKey = process.env.GEMINI_API_KEY || process.env.GROQ_API_KEY;
    if (!apiKey) {
      console.error('ERRO: GEMINI_API_KEY não encontrada no ambiente.');
      return res.status(400).json({ error: 'A chave Gemini (GEMINI_API_KEY) não foi configurada no servidor. Por favor, verifique as variáveis de ambiente.' });
    }

    const systemPrompt = `Você é o Nautilus AI Expert, um analista de trading quantitativo de elite. 
    Analise os dados históricos fornecidos (formato CSV) de robôs ou portfólios.
    Sua missão é fornecer análises precisas, identificar padrões de lucro/perda e responder dúvidas técnicas sobre o drawdown e métricas de desempenho.
    Seja extremamente preciso com números e datas. Use Markdown para formatar tabelas ou destaques se necessário.
    
    CONTEXTO DA ESTRATÉGIA:
    ${context}`;

    const geminiInstance = new GoogleGenerativeAI(apiKey);
    const geminiModel = geminiInstance.getGenerativeModel({
      model: GEMINI_MODEL,
      systemInstruction: systemPrompt,
      generationConfig: {
        temperature: 0.1,
        maxOutputTokens: 3000,
      }
    });

    const contents = messages.map((m: any) => ({
      role: m.role === 'assistant' || m.role === 'model' ? 'model' : 'user',
      parts: Array.isArray(m.parts) 
        ? m.parts 
        : [{ text: typeof m.content === 'string' ? m.content : (m.parts?.[0]?.text || '') }]
    }));

    const result = await geminiModel.generateContent({ contents });
    const responseText = result.response.text();

    res.json({ text: responseText });
  } catch (err: any) {
    console.error('Gemini API Error:', err?.message || err);
    res.status(500).json({ 
      error: 'Erro na comunicação com a IA (Gemini)', 
      details: err?.message || String(err) 
    });
  }
});

// ══════════════════════════════════════════════════════════
// BENCHMARK PROXY ENDPOINTS (bypass CORS from BCB / IBOV APIs)
// ══════════════════════════════════════════════════════════

// Internal helper to fetch from BCB and populate SQLite benchmark_cdi
async function fetchAndSaveBcbCdi() {
  const db = await getDb();
  const url = `https://api.bcb.gov.br/dados/serie/bcdata.sgs.4391/dados?formato=json&dataInicial=01/01/2020&dataFinal=31/12/2030`;
  const response = await fetch(url, {
    headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' }
  });
  const data = await response.json();
  if (Array.isArray(data)) {
    const stmt = await db.prepare(
      'INSERT OR REPLACE INTO benchmark_cdi (date, valor, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP)'
    );
    for (const item of data) {
      if (item && item.data && item.valor !== undefined) {
        const parts = item.data.split('/');
        if (parts.length === 3) {
          const [d, m, y] = parts;
          const monthKey = `${y}-${m.padStart(2, '0')}`;
          const valNum = parseFloat(String(item.valor).replace(',', '.'));
          if (!isNaN(valNum)) {
            await stmt.run(monthKey, valNum);
          }
        }
      }
    }
    await stmt.finalize();
  }
}

// GET /api/benchmarks/cdi?start=dd/MM/yyyy&end=dd/MM/yyyy
// Serves CDI series from local SQLite database (fast & offline-ready)
app.get('/api/benchmarks/cdi', async (req, res) => {
  try {
    const db = await getDb();
    let rows = await db.all('SELECT date, valor FROM benchmark_cdi ORDER BY date ASC');
    
    // Auto-seed if SQLite is empty
    if (rows.length === 0) {
      try {
        await fetchAndSaveBcbCdi();
        rows = await db.all('SELECT date, valor FROM benchmark_cdi ORDER BY date ASC');
      } catch (e) {
        console.error('Failed auto-seeding BCB CDI:', e);
      }
    }

    // Convert to format expected by frontend: [{ data: "DD/MM/YYYY", valor: "0.97" }]
    const result = rows.map(r => {
      const [y, m] = r.date.split('-');
      return {
        data: `01/${m}/${y}`,
        valor: String(r.valor)
      };
    });

    res.json(result);
  } catch (err) {
    console.error('BCB CDI get error:', err);
    res.status(500).json({ error: String(err) });
  }
});

// POST /api/benchmarks/cdi/sync
// Manually trigger sync with BCB API to update local database
app.post('/api/benchmarks/cdi/sync', async (req, res) => {
  try {
    await fetchAndSaveBcbCdi();
    const db = await getDb();
    const count = await db.get('SELECT COUNT(*) as cnt FROM benchmark_cdi');
    res.json({ success: true, count: count?.cnt || 0, message: 'CDI sincronizado com sucesso com o BCB!' });
  } catch (err) {
    console.error('BCB CDI sync error:', err);
    res.status(500).json({ success: false, error: String(err) });
  }
});

// GET /api/benchmarks/ibov?start=YYYY-MM-DD&end=YYYY-MM-DD
// Proxies IBOV historical quotes
app.get('/api/benchmarks/ibov', async (req, res) => {
  try {
    let start = (req.query.start as string) || '2020-01-01';
    let end = (req.query.end as string) || '2030-12-31';
    const url = `https://api.cotacoes.multtrader.com/historical/BVSP?start=${encodeURIComponent(start)}&end=${encodeURIComponent(end)}`;
    const response = await fetch(url);
    const data = await response.json();
    res.json(data);
  } catch (err) {
    console.error('IBOV proxy error:', err);
    res.status(500).json({ error: String(err) });
  }
});

app.listen(port, () => {
  console.log(`API Nautilus DataLab running on port ${port}`);
});
