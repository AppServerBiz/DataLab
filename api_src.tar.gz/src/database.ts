import sqlite3 from 'sqlite3';
import { open, Database } from 'sqlite';
import path from 'path';

let db: Database<sqlite3.Database, sqlite3.Statement> | null = null;

export async function getDb(): Promise<Database<sqlite3.Database, sqlite3.Statement>> {
  if (db) return db;

  const dbPath = process.env.DATABASE_PATH || path.resolve(__dirname, '..', 'nautilus.db');
  db = await open({ filename: dbPath, driver: sqlite3.Database });
  await db.exec('PRAGMA foreign_keys = ON;');

  await db.exec(`
    CREATE TABLE IF NOT EXISTS robots (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL UNIQUE,
      -- 10 Elite Metrics
      total_net_profit REAL DEFAULT 0,
      max_dd_equity REAL DEFAULT 0,
      max_dd_equity_pct REAL DEFAULT 0,
      profit_factor REAL DEFAULT 0,
      total_trades INTEGER DEFAULT 0,
      short_trades INTEGER DEFAULT 0,
      short_win_pct REAL DEFAULT 0,
      long_trades INTEGER DEFAULT 0,
      long_win_pct REAL DEFAULT 0,
      expected_payoff REAL DEFAULT 0,
      sharpe_ratio REAL DEFAULT 0,
      max_drawdown_abs REAL DEFAULT 0,
      initial_deposit REAL DEFAULT 10000,
      -- Extra metrics
      gross_profit REAL DEFAULT 0,
      gross_loss REAL DEFAULT 0,
      recovery_factor REAL DEFAULT 0,
      profitable_trades INTEGER DEFAULT 0,
      losing_trades INTEGER DEFAULT 0,
      win_rate REAL DEFAULT 0,
      avg_win REAL DEFAULT 0,
      avg_loss REAL DEFAULT 0,
      max_win REAL DEFAULT 0,
      max_loss REAL DEFAULT 0,
      max_consecutive_wins TEXT,
      max_consecutive_losses TEXT,
      avg_trade_duration TEXT,
      quality REAL DEFAULT 0,
      -- Config
      asset TEXT,
      period TEXT,
      timeframe TEXT,
      date_from TEXT,
      date_to TEXT,
      broker TEXT,
      parameters TEXT,
      total_months INTEGER DEFAULT 0,
      avg_profit_per_month REAL DEFAULT 0,
      total_lots REAL DEFAULT 0,
      lots_per_month REAL DEFAULT 0,
      max_lot_exposure REAL DEFAULT 0,
      max_entries_per_trade INTEGER DEFAULT 0,
      -- More detailed data
      equity_curve TEXT,
      monthly_drawdown TEXT,
      max_dd_from_csv REAL DEFAULT 0,
      max_dd_pct_from_csv REAL DEFAULT 0,
      -- UI state
      config_html TEXT,
      raw_html MEDIUMTEXT,
      raw_csv MEDIUMTEXT,
      approved INTEGER DEFAULT 0,
      status TEXT DEFAULT 'pending',
      var_95_dd_cap REAL DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS portfolios (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL UNIQUE,
      capital REAL DEFAULT 30000,
      target_dd REAL DEFAULT 5000,
      manual_dme REAL,
      locked INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS portfolio_robots (
      id TEXT PRIMARY KEY,
      portfolio_id TEXT NOT NULL,
      robot_id TEXT NOT NULL,
      weight REAL DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (portfolio_id) REFERENCES portfolios(id) ON DELETE CASCADE,
      FOREIGN KEY (robot_id) REFERENCES robots(id) ON DELETE CASCADE,
      UNIQUE(portfolio_id, robot_id)
    );

    CREATE TABLE IF NOT EXISTS benchmark_cdi (
      date TEXT PRIMARY KEY,
      valor REAL NOT NULL,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // Proper JS migrations outside the SQL string
  try { await db.exec('ALTER TABLE portfolios ADD COLUMN locked INTEGER DEFAULT 0;'); } catch (e) {}
  try { await db.exec('ALTER TABLE portfolios ADD COLUMN manual_dme REAL;'); } catch (e) {}
  try { await db.exec('ALTER TABLE robots ADD COLUMN var_95_dd_cap REAL DEFAULT 0;'); } catch (e) {}
  try { await db.exec('ALTER TABLE robots ADD COLUMN total_lots REAL DEFAULT 0;'); } catch (e) {}
  try { await db.exec('ALTER TABLE robots ADD COLUMN lots_per_month REAL DEFAULT 0;'); } catch (e) {}
  try { await db.exec('ALTER TABLE robots ADD COLUMN max_lot_exposure REAL DEFAULT 0;'); } catch (e) {}
  try { await db.exec('ALTER TABLE robots ADD COLUMN max_entries_per_trade INTEGER DEFAULT 0;'); } catch (e) {}

  // Automated Lot Repair for existing data
  (async () => {
    try {
      const { parseMT5BacktestHTML, parseCSVEquity } = await import('./parser');
      const robotsToFix = await db!.all('SELECT id, name, raw_html, raw_csv, total_months, initial_deposit, equity_curve FROM robots');
      if (robotsToFix.length > 0) {
        console.log(`[Database] Checking metrics and initial deposits for ${robotsToFix.length} robots...`);
        for (const r of robotsToFix) {
          let updated = false;
          let newTotalLots = r.total_lots;
          let newLotsPerMonth = r.lots_per_month;
          let newMaxLotExposure = r.max_lot_exposure;
          let newMaxEntries = r.max_entries_per_trade;
          let newInitialDeposit = r.initial_deposit;

          // 1. Repair Lots if needed
          if (!r.total_lots || r.total_lots === 0 || !r.max_lot_exposure || r.max_lot_exposure === 0) {
            if (r.raw_html) {
              let csvParsed = r.raw_csv ? parseCSVEquity(r.raw_csv, r.name) : null;
              const parsed = parseMT5BacktestHTML(r.raw_html, r.name, csvParsed);
              newTotalLots = parsed.metrics.total_lots;
              newLotsPerMonth = parsed.metrics.lots_per_month;
              newMaxLotExposure = parsed.metrics.max_lot_exposure;
              newMaxEntries = parsed.metrics.max_entries_per_trade;
              updated = true;
            }
          }

          // 2. Repair Initial Deposit if needed
          if (r.equity_curve) {
            try {
              const curve = JSON.parse(r.equity_curve);
              if (curve.length > 0) {
                const firstEquity = curve[0].equity;
                const firstBalance = curve[0].balance;
                const actualStart = firstBalance || firstEquity;
                if (actualStart > 0 && Math.abs(r.initial_deposit - actualStart) > 1) {
                  newInitialDeposit = actualStart;
                  updated = true;
                }
              }
            } catch (e) {}
          }

          if (updated) {
            await db!.run('UPDATE robots SET total_lots = ?, lots_per_month = ?, max_lot_exposure = ?, max_entries_per_trade = ?, initial_deposit = ? WHERE id = ?', 
              [newTotalLots, newLotsPerMonth, newMaxLotExposure, newMaxEntries, newInitialDeposit, r.id]);
          }
        }
        console.log(`[Database] Lot repair completed.`);
      }
    } catch (err) {
      console.warn('[Database] Failed to auto-repair lots:', err);
    }
  })();

  return db;
}
